#!/system/bin/sh
# ============================================================================
# CPU Scheduler Optimizer - WALT / SM7475
# Author: jtapzg
# ============================================================================

MODE="${1:-SYNC_NORMAL}"

w() { [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null; }

LITTLE_CORES="0 1 2 3"
BIG_CORES="4 5 6"
PRIME_CORE="7"

case "$MODE" in
    init)
        # Initial boot optimization
        w /proc/sys/kernel/sched_latency_ns "4000000"
        w /proc/sys/kernel/sched_min_granularity_ns "500000"
        w /proc/sys/kernel/sched_wakeup_granularity_ns "2000000"
        w /proc/sys/kernel/sched_migration_cost_ns "250000"
        w /proc/sys/kernel/sched_nr_migrate "32"
        w /proc/sys/kernel/sched_child_runs_first "1"
        for blk in /sys/block/sd*/queue; do
            [ -d "$blk" ] || continue
            avail=$(cat "$blk/scheduler" 2>/dev/null)
            echo "$avail" | grep -q "mq-deadline" && w "$blk/scheduler" "mq-deadline"
            w "$blk/read_ahead_kb" "128"
            w "$blk/nr_requests" "128"
            w "$blk/iostats" "0"
        done
        ;;
    SYNC_IDLE)
        w /proc/sys/kernel/sched_latency_ns "6000000"
        w /proc/sys/kernel/sched_min_granularity_ns "750000"
        w /proc/sys/kernel/sched_wakeup_granularity_ns "3000000"
        w /proc/sys/kernel/sched_migration_cost_ns "500000"
        w /proc/sys/kernel/sched_nr_migrate "16"
        for cpu in $LITTLE_CORES; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "90" && w "$sp/up_rate_limit_us" "1000" && w "$sp/down_rate_limit_us" "4000"
        done
        for cpu in $BIG_CORES $PRIME_CORE; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "85" && w "$sp/up_rate_limit_us" "1000" && w "$sp/down_rate_limit_us" "3000"
        done
        ;;
    SYNC_NORMAL)
        w /proc/sys/kernel/sched_latency_ns "4000000"
        w /proc/sys/kernel/sched_min_granularity_ns "500000"
        w /proc/sys/kernel/sched_wakeup_granularity_ns "2000000"
        w /proc/sys/kernel/sched_migration_cost_ns "250000"
        w /proc/sys/kernel/sched_nr_migrate "32"
        for cpu in $LITTLE_CORES; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "80" && w "$sp/up_rate_limit_us" "500" && w "$sp/down_rate_limit_us" "2000"
        done
        for cpu in $BIG_CORES $PRIME_CORE; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "75" && w "$sp/up_rate_limit_us" "500" && w "$sp/down_rate_limit_us" "1000"
        done
        ;;
    SYNC_COMBAT)
        w /proc/sys/kernel/sched_latency_ns "3000000"
        w /proc/sys/kernel/sched_min_granularity_ns "400000"
        w /proc/sys/kernel/sched_wakeup_granularity_ns "1500000"
        w /proc/sys/kernel/sched_migration_cost_ns "100000"
        w /proc/sys/kernel/sched_nr_migrate "64"
        for cpu in $LITTLE_CORES; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "65" && w "$sp/up_rate_limit_us" "250" && w "$sp/down_rate_limit_us" "1000"
        done
        for cpu in $BIG_CORES $PRIME_CORE; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "55" && w "$sp/up_rate_limit_us" "250" && w "$sp/down_rate_limit_us" "500"
        done
        ;;
    SYNC_BERSERK)
        w /proc/sys/kernel/sched_latency_ns "2000000"
        w /proc/sys/kernel/sched_min_granularity_ns "250000"
        w /proc/sys/kernel/sched_wakeup_granularity_ns "1000000"
        w /proc/sys/kernel/sched_migration_cost_ns "50000"
        w /proc/sys/kernel/sched_nr_migrate "128"
        for cpu in 0 1 2 3 4 5 6 7; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "40" && w "$sp/up_rate_limit_us" "0" && w "$sp/down_rate_limit_us" "500"
        done
        w /proc/sys/kernel/sched_schedstats "0"
        ;;
    SYNC_THERMAL)
        w /proc/sys/kernel/sched_latency_ns "6000000"
        w /proc/sys/kernel/sched_min_granularity_ns "750000"
        w /proc/sys/kernel/sched_wakeup_granularity_ns "3000000"
        w /proc/sys/kernel/sched_migration_cost_ns "500000"
        w /proc/sys/kernel/sched_nr_migrate "16"
        for cpu in $LITTLE_CORES; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "95" && w "$sp/up_rate_limit_us" "2000" && w "$sp/down_rate_limit_us" "5000"
        done
        for cpu in $BIG_CORES $PRIME_CORE; do
            sp="/sys/devices/system/cpu/cpu$cpu/cpufreq/schedutil"
            [ -d "$sp" ] && w "$sp/hispeed_load" "90" && w "$sp/up_rate_limit_us" "2000" && w "$sp/down_rate_limit_us" "4000"
        done
        ;;
esac
