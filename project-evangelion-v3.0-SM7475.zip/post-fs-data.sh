#!/system/bin/sh
# Project Evangelion - post-fs-data
MODDIR="${0%/*}"
sh "$MODDIR/govpreload.sh" 2>/dev/null &
