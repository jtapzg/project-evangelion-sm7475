#!/system/bin/sh
# ============================================================================
# GPU Optimizer - Adreno 725 (SM7475)
# Author: jtapzg
# ============================================================================

MODE="${1:-apply}"
LOGFILE="/data/adb/.config/project-evangelion/eva_gpu.log"

w() { [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null; }
log() { echo "[$(date '+%H:%M:%S')] GPU: $1" >> "$LOGFILE"; }

# Find GPU path
GPU=""
for p in /sys/class/kgsl/kgsl-3d0 /sys/devices/platform/soc/*.qcom,kgsl-3d0/kgsl/kgsl-3d0; do
    [ -d "$p" ] && GPU="$p" && break
done
[ -z "$GPU" ] && exit 0

# Find devfreq paths for bandwidth
BW_GPU="" ; BW_LLCC="" ; BW_DDR=""
for df in /sys/class/devfreq/*gpu*; do [ -d "$df" ] && BW_GPU="$df" && break; done
for df in /sys/class/devfreq/*llcc*; do [ -d "$df" ] && BW_LLCC="$df" && break; done
for df in /sys/class/devfreq/*ddr*cpu-llcc-ddr*; do [ -d "$df" ] && BW_DDR="$df" && break; done

case "$MODE" in
    apply|init|normal)
        w "$GPU/devfreq/governor" "msm-adreno-tz"
        w "$GPU/default_pwrlevel" "5"
        w "$GPU/min_pwrlevel" "5"
        w "$GPU/max_pwrlevel" "0"
        w "$GPU/throttling" "0"
        w "$GPU/force_clk_on" "1"
        w "$GPU/force_bus_on" "1"
        w "$GPU/force_rail_on" "1"
        w "$GPU/force_no_nap" "1"
        w "$GPU/bus_split" "1"
        w "$GPU/idle_timer" "80"
        w "$GPU/adreno_idler/idler_enabled" "0"
        w "$GPU/devfreq/adrenoboost" "2"
        [ -n "$BW_GPU" ] && w "$BW_GPU/governor" "bw_hwmon"
        [ -n "$BW_LLCC" ] && w "$BW_LLCC/governor" "bw_hwmon"
        [ -n "$BW_DDR" ] && w "$BW_DDR/governor" "bw_hwmon"
        log "Mode: $MODE (balanced)"
        ;;
    idle)
        w "$GPU/devfreq/governor" "msm-adreno-tz"
        w "$GPU/default_pwrlevel" "5"
        w "$GPU/throttling" "0"
        w "$GPU/force_clk_on" "0"
        w "$GPU/force_bus_on" "0"
        w "$GPU/force_no_nap" "0"
        w "$GPU/idle_timer" "80"
        w "$GPU/devfreq/adrenoboost" "0"
        log "Mode: idle"
        ;;
    combat)
        w "$GPU/devfreq/governor" "msm-adreno-tz"
        w "$GPU/default_pwrlevel" "2"
        w "$GPU/max_pwrlevel" "0"
        w "$GPU/throttling" "0"
        w "$GPU/force_clk_on" "1"
        w "$GPU/force_bus_on" "1"
        w "$GPU/force_rail_on" "1"
        w "$GPU/force_no_nap" "1"
        w "$GPU/bus_split" "0"
        w "$GPU/idle_timer" "10000"
        w "$GPU/devfreq/adrenoboost" "2"
        [ -n "$BW_GPU" ] && w "$BW_GPU/governor" "performance"
        [ -n "$BW_LLCC" ] && w "$BW_LLCC/governor" "performance"
        [ -n "$BW_DDR" ] && w "$BW_DDR/governor" "performance"
        log "Mode: combat"
        ;;
    berserk|boost)
        w "$GPU/devfreq/governor" "msm-adreno-tz"
        w "$GPU/default_pwrlevel" "0"
        w "$GPU/max_pwrlevel" "0"
        w "$GPU/min_pwrlevel" "0"
        w "$GPU/throttling" "0"
        w "$GPU/force_clk_on" "1"
        w "$GPU/force_bus_on" "1"
        w "$GPU/force_rail_on" "1"
        w "$GPU/force_no_nap" "1"
        w "$GPU/bus_split" "0"
        w "$GPU/idle_timer" "100000000"
        w "$GPU/devfreq/adrenoboost" "3"
        [ -n "$BW_GPU" ] && w "$BW_GPU/governor" "performance"
        [ -n "$BW_LLCC" ] && w "$BW_LLCC/governor" "performance"
        [ -n "$BW_DDR" ] && w "$BW_DDR/governor" "performance"
        log "Mode: berserk"
        ;;
    thermal)
        w "$GPU/devfreq/governor" "msm-adreno-tz"
        w "$GPU/default_pwrlevel" "5"
        w "$GPU/min_pwrlevel" "5"
        w "$GPU/throttling" "1"
        w "$GPU/force_clk_on" "0"
        w "$GPU/force_bus_on" "0"
        w "$GPU/force_rail_on" "0"
        w "$GPU/force_no_nap" "0"
        w "$GPU/bus_split" "1"
        w "$GPU/idle_timer" "40"
        w "$GPU/devfreq/adrenoboost" "0"
        [ -n "$BW_GPU" ] && w "$BW_GPU/governor" "bw_hwmon"
        [ -n "$BW_LLCC" ] && w "$BW_LLCC/governor" "bw_hwmon"
        [ -n "$BW_DDR" ] && w "$BW_DDR/governor" "bw_hwmon"
        log "Mode: thermal (throttled)"
        ;;
esac
