#!/system/bin/sh
# ============================================================================
# Project Evangelion - EVA Sync Engine v3.0
# Author: jtapzg
# Optimized for Poco F5 (SM7475 / Snapdragon 7+ Gen 2)
# Adaptive performance system - reads REAL device metrics
# Features: GPU burst, dynamic GPU gov, thermal control, game thread pinning,
#           network latency, RAM cache clear, game loading boost, debug logging
# ============================================================================

MODDIR="/data/adb/modules/project-evangelion"
BASEDIR="/data/adb/.config/project-evangelion"
STATEDIR="$BASEDIR/state"
PERFLIST="$BASEDIR/perflist.txt"
CONF="$BASEDIR/gov.conf"
ICON="file:///data/local/tmp/idk.png"
LOG="$BASEDIR/eva_debug.log"

# SM7475 Topology: 4x A510 little (0-3) + 3x A715 big (4-6) + 1x A715 prime (7)
LITTLE_CORES="0 1 2 3"
BIG_CORES="4 5 6"
PRIME_CORE="7"

# GPU sysfs path
GPU_PATH="/sys/class/kgsl/kgsl-3d0"

# ============================================================================
# Debug Logging
# ============================================================================
log_debug() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG" 2>/dev/null
}

log_rotate() {
    if [ -f "$LOG" ]; then
        local size
        size=$(stat -c%s "$LOG" 2>/dev/null || echo 0)
        if [ "$size" -gt 524288 ] 2>/dev/null; then
            tail -200 "$LOG" > "${LOG}.tmp" 2>/dev/null
            mv "${LOG}.tmp" "$LOG" 2>/dev/null
        fi
    fi
}

# Helper: safe write to sysfs
w() { [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null; }

# Ensure state directory exists with proper permissions
mkdir -p "$STATEDIR" 2>/dev/null
chmod 755 "$BASEDIR" 2>/dev/null
chmod 755 "$STATEDIR" 2>/dev/null

log_debug "========================================="
log_debug "EVA Sync Engine v3.0 starting"
log_debug "MODDIR=$MODDIR"
log_debug "BASEDIR=$BASEDIR"
log_debug "STATEDIR=$STATEDIR"
log_debug "========================================="

# ============================================================================
# EVA Anime Phrases (PT-BR)
# ============================================================================
eva_phrase() {
    case $((RANDOM % 10)) in
        0) echo "Supere seus limites." ;;
        1) echo "Sincronizacao EVA estavel." ;;
        2) echo "Modo EVA ativado." ;;
        3) echo "Limite de desempenho removido." ;;
        4) echo "Evolucao iniciada." ;;
        5) echo "Sincronizacao piloto-sistema completa." ;;
        6) echo "Modo Berserk ativado." ;;
        7) echo "Potencia maxima liberada." ;;
        8) echo "Sistema neural conectado." ;;
        9) echo "Despertar do EVA completo." ;;
    esac
}

# ============================================================================
# Toast / Notification helper
# ============================================================================
eva_notify() {
    local title="$1"
    local message="$2"
    su -lp 2000 -c "cmd notification post -t '$title' \
        -i '$ICON' \
        -I '$ICON' \
        'eva_sync' '$message'" >/dev/null 2>&1
}

# ============================================================================
# Read REAL CPU load from /proc/stat (delta-based, accurate)
# ============================================================================
PREV_TOTAL=0
PREV_IDLE=0

get_cpu_load() {
    local cpu_line
    cpu_line=$(head -1 /proc/stat 2>/dev/null)
    if [ -z "$cpu_line" ]; then
        echo "0"
        return
    fi

    local user nice system idle iowait irq softirq steal
    set -- $cpu_line
    shift  # remove "cpu" label
    user=${1:-0}; nice=${2:-0}; system=${3:-0}; idle=${4:-0}
    iowait=${5:-0}; irq=${6:-0}; softirq=${7:-0}; steal=${8:-0}

    local total=$((user + nice + system + idle + iowait + irq + softirq + steal))
    local idle_sum=$((idle + iowait))

    if [ "$PREV_TOTAL" -gt 0 ] 2>/dev/null; then
        local diff_total=$((total - PREV_TOTAL))
        local diff_idle=$((idle_sum - PREV_IDLE))
        if [ "$diff_total" -gt 0 ] 2>/dev/null; then
            local usage=$(( (diff_total - diff_idle) * 100 / diff_total ))
            PREV_TOTAL=$total
            PREV_IDLE=$idle_sum
            # Clamp 0-100
            [ "$usage" -lt 0 ] 2>/dev/null && usage=0
            [ "$usage" -gt 100 ] 2>/dev/null && usage=100
            echo "$usage"
            return
        fi
    fi

    PREV_TOTAL=$total
    PREV_IDLE=$idle_sum

    # Fallback: use /proc/loadavg
    local load
    local nprocs
    nprocs=$(nproc 2>/dev/null || echo 8)
    load=$(cat /proc/loadavg 2>/dev/null | awk '{printf "%.0f", $1 * 100 / '"$nprocs"'}')
    load=${load:-0}
    [ "$load" -gt 100 ] 2>/dev/null && load=100
    echo "$load"
}

# ============================================================================
# Read REAL GPU load (Adreno 725)
# ============================================================================
get_gpu_load() {
    local load=0

    # Method 1: gpu_busy_percentage (most common on Adreno)
    if [ -f "$GPU_PATH/gpu_busy_percentage" ]; then
        load=$(cat "$GPU_PATH/gpu_busy_percentage" 2>/dev/null | tr -dc '0-9')
    # Method 2: gpubusy (busy idle pair)
    elif [ -f "$GPU_PATH/gpubusy" ]; then
        local busy idle
        read busy idle < "$GPU_PATH/gpubusy" 2>/dev/null
        if [ -n "$busy" ] && [ -n "$idle" ] && [ "$idle" -gt 0 ] 2>/dev/null; then
            load=$((busy * 100 / idle))
        fi
    # Method 3: devfreq gpu_load
    elif [ -f "$GPU_PATH/devfreq/gpu_load" ]; then
        load=$(cat "$GPU_PATH/devfreq/gpu_load" 2>/dev/null | tr -dc '0-9')
    fi

    # Fallback: never return empty
    load=${load:-0}
    [ "$load" -gt 100 ] 2>/dev/null && load=100
    [ "$load" -lt 0 ] 2>/dev/null && load=0
    echo "$load"
}

# ============================================================================
# Read REAL temperature (millidegrees -> degrees)
# ============================================================================
get_temperature() {
    local temp=0
    for tz in /sys/class/thermal/thermal_zone*/temp; do
        [ -f "$tz" ] || continue
        local t
        t=$(cat "$tz" 2>/dev/null)
        [ -z "$t" ] && continue
        # Skip invalid/negative values
        [ "$t" -lt 0 ] 2>/dev/null && continue
        # Convert millidegrees to degrees if needed
        [ "$t" -gt 1000 ] 2>/dev/null && t=$((t / 1000))
        # Keep highest temperature that makes sense (< 120C)
        if [ "$t" -gt "$temp" ] 2>/dev/null && [ "$t" -lt 120 ] 2>/dev/null; then
            temp="$t"
        fi
    done
    echo "$temp"
}

# ============================================================================
# Get current foreground app (multiple methods for compatibility)
# ============================================================================
get_top_app() {
    local app

    # Method 1: dumpsys activity
    app=$(dumpsys activity activities 2>/dev/null | grep -E "mResumedActivity|mFocusedActivity" | head -1 | sed 's/.*u0 //' | cut -d'/' -f1 | tr -d ' ')

    # Method 2: cmd activity
    if [ -z "$app" ]; then
        app=$(cmd activity stack list 2>/dev/null | grep "0,0.*visible=true" | tr -d ' ' | cut -f2 -d: | cut -f1 -d/)
    fi

    # Method 3: dumpsys window
    if [ -z "$app" ]; then
        app=$(dumpsys window 2>/dev/null | grep -E "mCurrentFocus|mFocusedApp" | head -1 | sed 's/.*{[^ ]* [^ ]* //' | cut -d'/' -f1 | tr -d '}')
    fi

    # Fallback
    app=${app:-"---"}
    echo "$app"
}

# ============================================================================
# Detect game engine from process memory maps
# ============================================================================
detect_game_engine() {
    local pkg="$1"
    local engine="unknown"

    [ -z "$pkg" ] && echo "$engine" && return

    local pid
    pid=$(pidof "$pkg" 2>/dev/null)
    [ -z "$pid" ] && echo "$engine" && return

    local maps="/proc/$pid/maps"
    [ ! -f "$maps" ] && echo "$engine" && return

    if grep -q "libunity.so\|libil2cpp.so" "$maps" 2>/dev/null; then
        engine="unity"
    elif grep -q "libUE4.so\|libUnreal.so" "$maps" 2>/dev/null; then
        engine="unreal"
    elif grep -q "libgodot_android.so\|libgodot.so" "$maps" 2>/dev/null; then
        engine="godot"
    elif grep -q "libcocos2dcpp.so" "$maps" 2>/dev/null; then
        engine="cocos"
    elif grep -q "libflutter.so" "$maps" 2>/dev/null; then
        engine="flutter"
    fi

    echo "$engine"
}

# ============================================================================
# Check if app is a game (from perflist)
# ============================================================================
is_game() {
    local app="$1"
    [ -z "$app" ] && return 1
    [ ! -f "$PERFLIST" ] && return 1
    grep -qx "$app" "$PERFLIST" 2>/dev/null
}

# ============================================================================
# Check screen / home state
# ============================================================================
is_screen_off() {
    dumpsys power 2>/dev/null | grep -q "mWakefulness=Asleep"
}

is_home_screen() {
    local app="$1"
    local launcher
    launcher=$(cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep "packageName=" | head -1 | sed 's/.*packageName=//' | tr -d ' ')
    [ "$app" = "$launcher" ]
}

# ============================================================================
# Calculate EVA sync level (0-100)
# ============================================================================
calculate_sync_level() {
    local cpu_load="$1"
    local gpu_load="$2"
    local temp="$3"
    local is_gaming="$4"

    local sync=20

    if [ "$is_gaming" = "1" ]; then
        sync=70
        if [ "$gpu_load" -gt 90 ] 2>/dev/null; then
            sync=100
        elif [ "$gpu_load" -gt 70 ] 2>/dev/null; then
            sync=$((80 + (gpu_load - 70) * 2 / 3))
        elif [ "$gpu_load" -gt 40 ] 2>/dev/null; then
            sync=$((70 + (gpu_load - 40) / 3))
        fi
        if [ "$cpu_load" -gt 80 ] 2>/dev/null; then
            sync=$((sync + 5))
        fi
        if [ "$temp" -gt 45 ] 2>/dev/null; then
            sync=$((sync - (temp - 45) * 2))
        fi
    else
        if [ "$cpu_load" -gt 60 ] 2>/dev/null; then
            sync=$((40 + cpu_load / 3))
        elif [ "$cpu_load" -gt 30 ] 2>/dev/null; then
            sync=$((30 + cpu_load / 5))
        else
            sync=$((20 + cpu_load / 4))
        fi
    fi

    [ "$sync" -lt 0 ] 2>/dev/null && sync=0
    [ "$sync" -gt 100 ] 2>/dev/null && sync=100
    echo "$sync"
}

# ============================================================================
# Determine EVA mode from sync level + thermal awareness
# ============================================================================
get_eva_mode() {
    local sync="$1"
    local temp="$2"

    # THERMAL override: if temp > 50C, force THERMAL mode
    if [ -n "$temp" ] && [ "$temp" -gt 50 ] 2>/dev/null; then
        echo "SYNC_THERMAL"
        return
    fi

    if [ "$sync" -ge 90 ] 2>/dev/null; then
        echo "SYNC_BERSERK"
    elif [ "$sync" -ge 65 ] 2>/dev/null; then
        echo "SYNC_COMBAT"
    elif [ "$sync" -ge 35 ] 2>/dev/null; then
        echo "SYNC_NORMAL"
    else
        echo "SYNC_IDLE"
    fi
}

get_mode_display() {
    case "$1" in
        SYNC_IDLE)    echo "IDLE" ;;
        SYNC_NORMAL)  echo "NORMAL" ;;
        SYNC_COMBAT)  echo "COMBAT" ;;
        SYNC_BERSERK) echo "BERSERK" ;;
        SYNC_THERMAL) echo "THERMAL" ;;
        *)            echo "DESCONHECIDO" ;;
    esac
}

# ============================================================================
# Apply governor based on EVA mode (SM7475-aware)
# ============================================================================
apply_governor() {
    local mode="$1"
    local gov

    local gov_normal gov_game gov_powersave
    gov_normal=$(grep '^normal=' "$CONF" 2>/dev/null | cut -d= -f2)
    gov_game=$(grep '^game=' "$CONF" 2>/dev/null | cut -d= -f2)
    gov_powersave=$(grep '^powersave=' "$CONF" 2>/dev/null | cut -d= -f2)

    [ -z "$gov_normal" ] && gov_normal="schedutil"
    [ -z "$gov_game" ] && gov_game="schedutil"
    [ -z "$gov_powersave" ] && gov_powersave="schedutil"

    case "$mode" in
        SYNC_IDLE)    gov="$gov_powersave" ;;
        SYNC_NORMAL)  gov="$gov_normal" ;;
        SYNC_COMBAT)  gov="$gov_game" ;;
        SYNC_BERSERK) gov="$gov_game" ;;
        SYNC_THERMAL) gov="$gov_powersave" ;;
        *)            gov="$gov_normal" ;;
    esac

    for cpu in /sys/devices/system/cpu/*/cpufreq/scaling_governor; do
        [ -f "$cpu" ] && echo "$gov" > "$cpu" 2>/dev/null
    done
    log_debug "Governor applied: $gov (mode=$mode)"
}

# ============================================================================
# Apply schedtune boost based on mode
# ============================================================================
apply_schedtune() {
    local mode="$1"
    local boost=1
    local prefer_idle=0

    case "$mode" in
        SYNC_IDLE)    boost=0; prefer_idle=1 ;;
        SYNC_NORMAL)  boost=1; prefer_idle=0 ;;
        SYNC_COMBAT)  boost=15; prefer_idle=1 ;;
        SYNC_BERSERK) boost=25; prefer_idle=1 ;;
        SYNC_THERMAL) boost=0; prefer_idle=1 ;;
    esac

    [ -w /dev/stune/top-app/schedtune.boost ] && echo "$boost" > /dev/stune/top-app/schedtune.boost
    [ -w /dev/stune/top-app/schedtune.prefer_idle ] && echo "$prefer_idle" > /dev/stune/top-app/schedtune.prefer_idle
}

# ============================================================================
# Apply game process priority boost (SM7475 topology-aware)
# ============================================================================
apply_game_priority() {
    local pkg="$1"
    local mode="$2"

    [ -z "$pkg" ] && return

    local pid
    pid=$(pidof "$pkg" 2>/dev/null)
    [ -z "$pid" ] && return

    case "$mode" in
        SYNC_COMBAT)
            renice -10 -p "$pid" >/dev/null 2>&1
            # Pin to big+prime cores (4-7 = mask F0)
            taskset -p f0 "$pid" >/dev/null 2>&1
            ;;
        SYNC_BERSERK)
            renice -15 -p "$pid" >/dev/null 2>&1
            # Pin to big+prime cores (4-7 = mask F0)
            taskset -p f0 "$pid" >/dev/null 2>&1
            ;;
        SYNC_THERMAL)
            # In thermal mode, reset to normal priority
            renice 0 -p "$pid" >/dev/null 2>&1
            # Allow all cores
            taskset -p ff "$pid" >/dev/null 2>&1
            ;;
    esac
}

# ============================================================================
# Apply engine-specific optimizations
# ============================================================================
apply_engine_profile() {
    local engine="$1"
    local mode="$2"

    case "$engine" in
        unity)
            if [ "$mode" = "SYNC_COMBAT" ] || [ "$mode" = "SYNC_BERSERK" ]; then
                [ -w /dev/stune/top-app/schedtune.boost ] && echo 20 > /dev/stune/top-app/schedtune.boost
            fi
            ;;
        unreal)
            if [ -f "$MODDIR/gpu_optimizer.sh" ]; then
                sh "$MODDIR/gpu_optimizer.sh" "boost" &
            fi
            ;;
        godot|cocos)
            if [ "$mode" = "SYNC_COMBAT" ] || [ "$mode" = "SYNC_BERSERK" ]; then
                [ -w /dev/stune/top-app/schedtune.boost ] && echo 10 > /dev/stune/top-app/schedtune.boost
            fi
            ;;
    esac
    log_debug "Engine profile applied: engine=$engine mode=$mode"
}

# ============================================================================
# GPU Burst Mode - activate/deactivate GPU forced clocks
# ============================================================================
GPU_BURST_ACTIVE=0

activate_gpu_burst() {
    if [ -d "$GPU_PATH" ] && [ "$GPU_BURST_ACTIVE" != "1" ]; then
        w "$GPU_PATH/force_bus_on" "1"
        w "$GPU_PATH/force_clk_on" "1"
        w "$GPU_PATH/force_rail_on" "1"
        w "$GPU_PATH/force_no_nap" "1"
        w "$GPU_PATH/idle_timer" "10000"
        w "$GPU_PATH/bus_split" "0"
        GPU_BURST_ACTIVE=1
        log_debug "GPU burst ACTIVATED"
    fi
}

deactivate_gpu_burst() {
    if [ -d "$GPU_PATH" ] && [ "$GPU_BURST_ACTIVE" = "1" ]; then
        w "$GPU_PATH/force_bus_on" "0"
        w "$GPU_PATH/force_clk_on" "0"
        w "$GPU_PATH/force_rail_on" "0"
        w "$GPU_PATH/force_no_nap" "0"
        w "$GPU_PATH/idle_timer" "80"
        w "$GPU_PATH/bus_split" "1"
        GPU_BURST_ACTIVE=0
        log_debug "GPU burst DEACTIVATED"
    fi
}

# ============================================================================
# Dynamic GPU Governor - switch to performance when GPU > 90%
# ============================================================================
GPU_GOV_BOOSTED=0

apply_dynamic_gpu_governor() {
    local gpu_load="$1"
    local mode="$2"

    if [ ! -d "$GPU_PATH/devfreq" ]; then
        return
    fi

    # In THERMAL mode, always use power-saving governor
    if [ "$mode" = "SYNC_THERMAL" ]; then
        if [ "$GPU_GOV_BOOSTED" = "1" ]; then
            w "$GPU_PATH/devfreq/governor" "msm-adreno-tz"
            GPU_GOV_BOOSTED=0
            log_debug "GPU governor -> msm-adreno-tz (thermal)"
        fi
        return
    fi

    if [ "$gpu_load" -gt 90 ] 2>/dev/null && [ "$GPU_GOV_BOOSTED" != "1" ]; then
        w "$GPU_PATH/devfreq/governor" "performance"
        GPU_GOV_BOOSTED=1
        log_debug "GPU governor -> performance (load=$gpu_load%)"
    elif [ "$gpu_load" -lt 50 ] 2>/dev/null && [ "$GPU_GOV_BOOSTED" = "1" ]; then
        w "$GPU_PATH/devfreq/governor" "msm-adreno-tz"
        GPU_GOV_BOOSTED=0
        log_debug "GPU governor -> msm-adreno-tz (load=$gpu_load%)"
    fi
}

# ============================================================================
# Smart Thermal Control
# ============================================================================
THERMAL_THROTTLED=0

apply_thermal_control() {
    local temp="$1"
    local mode="$2"

    if [ "$temp" -gt 50 ] 2>/dev/null; then
        # Critical: disable all boosts
        if [ "$THERMAL_THROTTLED" != "2" ]; then
            deactivate_gpu_burst
            w "$GPU_PATH/devfreq/governor" "msm-adreno-tz"
            GPU_GOV_BOOSTED=0
            w "$GPU_PATH/throttling" "1"
            # Reduce scheduler aggressiveness
            w /proc/sys/kernel/sched_latency_ns "6000000"
            w /proc/sys/kernel/sched_min_granularity_ns "750000"
            w /proc/sys/kernel/sched_wakeup_granularity_ns "3000000"
            THERMAL_THROTTLED=2
            log_debug "THERMAL CRITICAL: temp=$temp, all boosts disabled"
        fi
    elif [ "$temp" -gt 45 ] 2>/dev/null; then
        # Warning: reduce GPU boost
        if [ "$THERMAL_THROTTLED" != "1" ]; then
            deactivate_gpu_burst
            if [ "$GPU_GOV_BOOSTED" = "1" ]; then
                w "$GPU_PATH/devfreq/governor" "msm-adreno-tz"
                GPU_GOV_BOOSTED=0
            fi
            w "$GPU_PATH/throttling" "0"
            THERMAL_THROTTLED=1
            log_debug "THERMAL WARNING: temp=$temp, GPU boost reduced"
        fi
    else
        # Normal: reset throttle state
        if [ "$THERMAL_THROTTLED" != "0" ]; then
            w "$GPU_PATH/throttling" "0"
            THERMAL_THROTTLED=0
            log_debug "THERMAL OK: temp=$temp, normal operation"
        fi
    fi
}

# ============================================================================
# Network Low Latency Mode for Gaming
# ============================================================================
NET_LOW_LATENCY=0

apply_network_gaming() {
    local enable="$1"

    if [ "$enable" = "1" ] && [ "$NET_LOW_LATENCY" != "1" ]; then
        [ -w /proc/sys/net/ipv4/tcp_low_latency ] && echo "1" > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null
        [ -w /proc/sys/net/ipv4/tcp_nodelay ] && echo "1" > /proc/sys/net/ipv4/tcp_nodelay 2>/dev/null
        NET_LOW_LATENCY=1
        log_debug "Network low latency mode ENABLED"
    elif [ "$enable" = "0" ] && [ "$NET_LOW_LATENCY" = "1" ]; then
        [ -w /proc/sys/net/ipv4/tcp_low_latency ] && echo "0" > /proc/sys/net/ipv4/tcp_low_latency 2>/dev/null
        NET_LOW_LATENCY=0
        log_debug "Network low latency mode DISABLED"
    fi
}

# ============================================================================
# RAM Cache Clear before game launch
# ============================================================================
clear_ram_cache() {
    sync 2>/dev/null
    echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
    log_debug "RAM cache cleared (drop_caches=3)"
}

# ============================================================================
# Game Loading Boost (30s max GPU on game launch)
# ============================================================================
LOADING_BOOST_PID=""

game_loading_boost() {
    local pkg="$1"
    log_debug "Game loading boost START for $pkg (30s)"

    # Force GPU to max for 30 seconds
    if [ -d "$GPU_PATH" ]; then
        w "$GPU_PATH/devfreq/governor" "performance"
        w "$GPU_PATH/default_pwrlevel" "0"
        w "$GPU_PATH/max_pwrlevel" "0"
        w "$GPU_PATH/min_pwrlevel" "0"

        # Schedule restore after 30 seconds (in background)
        (
            sleep 30
            w "$GPU_PATH/devfreq/governor" "msm-adreno-tz"
            w "$GPU_PATH/default_pwrlevel" "5"
            w "$GPU_PATH/min_pwrlevel" "5"
            log_debug "Game loading boost END for $pkg"
        ) &
        LOADING_BOOST_PID=$!
    fi
}

# ============================================================================
# Apply CPU scheduler latency tuning for game mode
# ============================================================================
apply_game_scheduler_latency() {
    local mode="$1"

    case "$mode" in
        SYNC_COMBAT)
            w /proc/sys/kernel/sched_latency_ns "3000000"
            w /proc/sys/kernel/sched_min_granularity_ns "400000"
            w /proc/sys/kernel/sched_wakeup_granularity_ns "1500000"
            w /proc/sys/kernel/sched_migration_cost_ns "100000"
            w /proc/sys/kernel/sched_nr_migrate "64"
            log_debug "Scheduler latency: COMBAT (3ms/400us/1.5ms)"
            ;;
        SYNC_BERSERK)
            w /proc/sys/kernel/sched_latency_ns "2000000"
            w /proc/sys/kernel/sched_min_granularity_ns "250000"
            w /proc/sys/kernel/sched_wakeup_granularity_ns "1000000"
            w /proc/sys/kernel/sched_migration_cost_ns "50000"
            w /proc/sys/kernel/sched_nr_migrate "128"
            log_debug "Scheduler latency: BERSERK (2ms/250us/1ms)"
            ;;
        SYNC_THERMAL)
            w /proc/sys/kernel/sched_latency_ns "6000000"
            w /proc/sys/kernel/sched_min_granularity_ns "750000"
            w /proc/sys/kernel/sched_wakeup_granularity_ns "3000000"
            w /proc/sys/kernel/sched_migration_cost_ns "500000"
            w /proc/sys/kernel/sched_nr_migrate "16"
            log_debug "Scheduler latency: THERMAL (6ms/750us/3ms)"
            ;;
        SYNC_IDLE)
            w /proc/sys/kernel/sched_latency_ns "6000000"
            w /proc/sys/kernel/sched_min_granularity_ns "750000"
            w /proc/sys/kernel/sched_wakeup_granularity_ns "3000000"
            w /proc/sys/kernel/sched_migration_cost_ns "500000"
            w /proc/sys/kernel/sched_nr_migrate "16"
            log_debug "Scheduler latency: IDLE"
            ;;
        *)
            w /proc/sys/kernel/sched_latency_ns "4000000"
            w /proc/sys/kernel/sched_min_granularity_ns "500000"
            w /proc/sys/kernel/sched_wakeup_granularity_ns "2000000"
            w /proc/sys/kernel/sched_migration_cost_ns "250000"
            w /proc/sys/kernel/sched_nr_migrate "32"
            log_debug "Scheduler latency: NORMAL"
            ;;
    esac
}

# ============================================================================
# Shader cache warmup for game
# ============================================================================
shader_cache_warmup() {
    local pkg="$1"
    [ -z "$pkg" ] && return

    local cache_dirs="/data/data/$pkg/cache /data/data/$pkg/code_cache /storage/emulated/0/Android/data/$pkg/cache"

    for dir in $cache_dirs; do
        if [ -d "$dir" ]; then
            find "$dir" -type f -name "*.shader" -o -name "*.spv" -o -name "*.cache" -o -name "*.bin" 2>/dev/null | while read -r f; do
                dd if="$f" of=/dev/null bs=64k 2>/dev/null &
            done
        fi
    done
}

# ============================================================================
# Asset preload for game
# ============================================================================
preload_game_assets() {
    local pkg="$1"
    [ -z "$pkg" ] && return

    local mem_total
    mem_total=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    local size_limit=$((mem_total / 10 * 1024))

    local code_path
    code_path=$(dumpsys package "$pkg" 2>/dev/null | grep "codePath=" | head -1 | sed 's/.*codePath=//')

    if [ -n "$code_path" ] && [ -d "$code_path" ]; then
        for lib in libunity.so libil2cpp.so libUE4.so libUnreal.so libmain.so libgodot_android.so libcocos2dcpp.so; do
            local lib_path
            lib_path=$(find "$code_path" -name "$lib" -type f 2>/dev/null | head -1)
            if [ -n "$lib_path" ]; then
                local fsize
                fsize=$(stat -c%s "$lib_path" 2>/dev/null)
                if [ -n "$fsize" ] && [ "$fsize" -lt "$size_limit" ] 2>/dev/null; then
                    dd if="$lib_path" of=/dev/null bs=1M 2>/dev/null &
                fi
            fi
        done
    fi

    for data_dir in "/data/user/0/$pkg" "/storage/emulated/0/Android/data/$pkg"; do
        if [ -d "$data_dir" ]; then
            find "$data_dir" -type f \( -name "*.so" -o -name "*.obb" \) 2>/dev/null | head -20 | while read -r asset; do
                local fsize
                fsize=$(stat -c%s "$asset" 2>/dev/null)
                if [ -n "$fsize" ] && [ "$fsize" -lt "$size_limit" ] 2>/dev/null; then
                    dd if="$asset" of=/dev/null bs=1M 2>/dev/null &
                fi
            done
        fi
    done
}

# ============================================================================
# Main EVA Sync Loop
# ============================================================================
eva_sync_main() {
    # Self-deprioritize to avoid impacting performance
    renice -n 19 -p $$ >/dev/null 2>&1

    local current_mode=""
    local current_app=""
    local prev_game_app=""
    local loop_count=0

    log_debug "EVA Sync main loop starting (PID=$$)"
    eva_notify "Projeto EVANGELION" "EVA Sync Engine v3.0 ativo | $(eva_phrase)"

    while true; do
        sleep 2

        # Check if EVA sync is enabled
        local eva_on
        eva_on=$(cat "$BASEDIR/eva_sync_enabled" 2>/dev/null)
        if [ "$eva_on" = "0" ]; then
            log_debug "EVA sync disabled, sleeping..."
            sleep 5
            continue
        fi

        # Check if battery saver is on
        if [ "$(settings get global low_power 2>/dev/null)" = "1" ]; then
            if [ "$current_mode" != "SYNC_IDLE" ]; then
                current_mode="SYNC_IDLE"
                apply_governor "SYNC_IDLE"
                apply_schedtune "SYNC_IDLE"
                apply_game_scheduler_latency "SYNC_IDLE"
                deactivate_gpu_burst
                apply_network_gaming "0"
                echo "SYNC_IDLE" > "$STATEDIR/current_mode"
                echo "10" > "$STATEDIR/sync_level"
                eva_notify "Projeto EVANGELION" "Economia de bateria ativa | Sincronizacao EVA: 10%"
                log_debug "Battery saver ON -> SYNC_IDLE"
            fi
            sleep 10
            continue
        fi

        # Check screen state
        if is_screen_off; then
            if [ "$current_mode" != "SYNC_IDLE" ]; then
                current_mode="SYNC_IDLE"
                apply_governor "SYNC_IDLE"
                apply_schedtune "SYNC_IDLE"
                apply_game_scheduler_latency "SYNC_IDLE"
                deactivate_gpu_burst
                apply_network_gaming "0"
                echo "SYNC_IDLE" > "$STATEDIR/current_mode"
                echo "5" > "$STATEDIR/sync_level"
                log_debug "Screen OFF -> SYNC_IDLE"
            fi
            sleep 10
            continue
        fi

        # ---- Get REAL system metrics ----
        local cpu_load gpu_load temp top_app
        cpu_load=$(get_cpu_load)
        gpu_load=$(get_gpu_load)
        temp=$(get_temperature)
        top_app=$(get_top_app)

        # Ensure values are never empty
        cpu_load=${cpu_load:-0}
        gpu_load=${gpu_load:-0}
        temp=${temp:-0}
        top_app=${top_app:-"---"}

        # ---- Smart thermal control (runs every cycle) ----
        apply_thermal_control "$temp" "$current_mode"

        # Determine if gaming
        local is_gaming=0
        if is_game "$top_app"; then
            is_gaming=1
        fi

        # Check if on home screen
        if is_home_screen "$top_app"; then
            is_gaming=0
        fi

        # Calculate sync level and mode (thermal-aware)
        local sync_level new_mode
        sync_level=$(calculate_sync_level "$cpu_load" "$gpu_load" "$temp" "$is_gaming")
        new_mode=$(get_eva_mode "$sync_level" "$temp")

        # ---- Write ALL state files for WebUI ----
        echo "$new_mode" > "$STATEDIR/current_mode"
        echo "$sync_level" > "$STATEDIR/sync_level"
        echo "$top_app" > "$STATEDIR/current_app"
        echo "$cpu_load" > "$STATEDIR/cpu_load"
        echo "$gpu_load" > "$STATEDIR/gpu_load"
        echo "$temp" > "$STATEDIR/temperature"

        # ---- Dynamic GPU governor (load-based) ----
        apply_dynamic_gpu_governor "$gpu_load" "$new_mode"

        # ---- Mode changed - apply new settings + toast ----
        if [ "$new_mode" != "$current_mode" ]; then
            local mode_display
            mode_display=$(get_mode_display "$new_mode")

            # Apply governor, schedtune, and scheduler latency
            apply_governor "$new_mode"
            apply_schedtune "$new_mode"
            apply_game_scheduler_latency "$new_mode"

            # GPU burst control based on mode
            case "$new_mode" in
                SYNC_COMBAT|SYNC_BERSERK)
                    # Only activate GPU burst if not thermally throttled
                    if [ "$THERMAL_THROTTLED" = "0" ]; then
                        activate_gpu_burst
                    fi
                    ;;
                *)
                    deactivate_gpu_burst
                    ;;
            esac

            # Apply memory and scheduler optimizations via external scripts
            if [ -f "$MODDIR/memory_optimizer.sh" ]; then
                sh "$MODDIR/memory_optimizer.sh" "$new_mode" &
            fi
            if [ -f "$MODDIR/scheduler_optimizer.sh" ]; then
                sh "$MODDIR/scheduler_optimizer.sh" "$new_mode" &
            fi

            # GPU optimizer mode
            if [ -f "$MODDIR/gpu_optimizer.sh" ]; then
                case "$new_mode" in
                    SYNC_IDLE)    sh "$MODDIR/gpu_optimizer.sh" "idle" & ;;
                    SYNC_COMBAT)  sh "$MODDIR/gpu_optimizer.sh" "combat" & ;;
                    SYNC_BERSERK) sh "$MODDIR/gpu_optimizer.sh" "berserk" & ;;
                    SYNC_THERMAL) sh "$MODDIR/gpu_optimizer.sh" "idle" & ;;
                    *)            sh "$MODDIR/gpu_optimizer.sh" "normal" & ;;
                esac
            fi

            # Toast notification on mode change
            local phrase
            phrase=$(eva_phrase)
            eva_notify "Projeto EVANGELION" "Sincronizacao EVA: ${sync_level}% | Modo ${mode_display} ativado | $phrase"

            log_debug "MODE CHANGE: $current_mode -> $new_mode (sync=$sync_level% cpu=$cpu_load% gpu=$gpu_load% temp=${temp}C)"
            current_mode="$new_mode"
        fi

        # ---- Game-specific optimizations ----
        if [ "$is_gaming" = "1" ]; then
            # Detect engine
            local engine
            engine=$(detect_game_engine "$top_app")
            echo "$engine" > "$STATEDIR/game_engine"

            # Enable network low latency for gaming
            apply_network_gaming "1"

            # New game detected
            if [ "$top_app" != "$prev_game_app" ]; then
                prev_game_app="$top_app"

                log_debug "NEW GAME DETECTED: $top_app (engine=$engine)"

                # Clear RAM cache before game
                clear_ram_cache

                # Game loading boost (30s GPU max)
                if [ "$THERMAL_THROTTLED" = "0" ]; then
                    game_loading_boost "$top_app"
                fi

                # Apply engine profile
                apply_engine_profile "$engine" "$new_mode"

                # Shader warmup
                shader_cache_warmup "$top_app"

                # Asset preload
                local preload_cfg
                preload_cfg=$(cat "$BASEDIR/preload_enabled" 2>/dev/null)
                if [ "$preload_cfg" = "1" ]; then
                    preload_game_assets "$top_app"
                fi

                # Toast: game detected
                local engine_display
                case "$engine" in
                    unity)   engine_display="Unity" ;;
                    unreal)  engine_display="Unreal Engine" ;;
                    godot)   engine_display="Godot" ;;
                    cocos)   engine_display="Cocos2d" ;;
                    flutter) engine_display="Flutter" ;;
                    *)       engine_display="Desconhecido" ;;
                esac
                eva_notify "Projeto EVANGELION" "Jogo detectado: $top_app | Engine: $engine_display | Otimizando..."
            fi

            # Apply game priority if in combat/berserk/thermal (every cycle for thread pinning)
            apply_game_priority "$top_app" "$new_mode"
        else
            echo "unknown" > "$STATEDIR/game_engine"
            prev_game_app=""
            # Disable network low latency when not gaming
            apply_network_gaming "0"
        fi

        # Update app tracking
        current_app="$top_app"

        # Periodic logging (every ~60s = 30 cycles)
        loop_count=$((loop_count + 1))
        if [ $((loop_count % 30)) -eq 0 ]; then
            log_debug "STATUS: mode=$current_mode cpu=$cpu_load% gpu=$gpu_load% temp=${temp}C app=$top_app gaming=$is_gaming gpu_burst=$GPU_BURST_ACTIVE thermal=$THERMAL_THROTTLED"
            log_rotate
            loop_count=0
        fi
    done
}

# ============================================================================
# Entry point - with error protection
# ============================================================================
log_debug "Entry point reached, checking eva_sync_enabled..."
eva_enabled=$(cat "$BASEDIR/eva_sync_enabled" 2>/dev/null)
if [ "$eva_enabled" != "0" ]; then
    log_debug "EVA sync enabled, starting main loop"
    eva_sync_main
else
    log_debug "EVA sync disabled (eva_sync_enabled=$eva_enabled), exiting"
fi
