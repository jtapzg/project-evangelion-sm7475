#!/system/bin/sh
# Governor preload - runs early in boot
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$cpu" ] && echo "schedutil" > "$cpu" 2>/dev/null
done
