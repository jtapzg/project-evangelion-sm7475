#!/system/bin/sh
# ============================================================================
# SurfaceFlinger Frame Pacing Optimizer
# Optimized for Poco F5 (120Hz AMOLED)
# Author: jtapzg
# ============================================================================

BASEDIR="/data/adb/.config/project-evangelion"
LOGFILE="$BASEDIR/eva_sfopt.log"

log() { echo "[$(date '+%H:%M:%S')] SFOPT: $1" >> "$LOGFILE"; }

get_refresh_rate() {
    local rate=""
    rate=$(dumpsys display 2>/dev/null | grep -oE "refreshRate=[0-9.]+" | head -1 | tr -dc '0-9.')
    [ -z "$rate" ] && rate="120"
    echo "$rate"
}

sleep 15

PREV_RATE=""

while true; do
    [ -f "$BASEDIR/sfopt_enabled" ] && [ "$(cat "$BASEDIR/sfopt_enabled" 2>/dev/null)" = "0" ] && {
        sleep 10
        continue
    }

    RATE=$(get_refresh_rate)

    if [ "$RATE" != "$PREV_RATE" ]; then
        log "Refresh rate: ${RATE}Hz"

        case "${RATE%.*}" in
            120)
                VSYNC_NS="8333333"
                PHASE_EARLY="-4166666"
                PHASE_LATE="-2083333"
                ;;
            90)
                VSYNC_NS="11111111"
                PHASE_EARLY="-5555555"
                PHASE_LATE="-2777777"
                ;;
            60|*)
                VSYNC_NS="16666666"
                PHASE_EARLY="-8333333"
                PHASE_LATE="-4166666"
                ;;
        esac

        setprop debug.sf.early_phase_offset_ns "$PHASE_EARLY" 2>/dev/null
        setprop debug.sf.early_gl_phase_offset_ns "$PHASE_EARLY" 2>/dev/null
        setprop debug.sf.early_app_phase_offset_ns "$PHASE_EARLY" 2>/dev/null
        setprop debug.sf.early_gl_app_phase_offset_ns "$PHASE_EARLY" 2>/dev/null
        setprop debug.sf.late_sf_phase_offset_ns "$PHASE_LATE" 2>/dev/null
        setprop debug.sf.late_app_phase_offset_ns "$PHASE_LATE" 2>/dev/null
        setprop debug.sf.phase_offset_threshold_for_next_vsync_ns "$VSYNC_NS" 2>/dev/null
        setprop debug.sf.use_phase_offsets_as_durations 1 2>/dev/null
        setprop debug.sf.latch_unsignaled 1 2>/dev/null
        setprop debug.sf.disable_backpressure 1 2>/dev/null

        PREV_RATE="$RATE"
        log "Frame pacing applied for ${RATE}Hz"
    fi

    sleep 30
done
