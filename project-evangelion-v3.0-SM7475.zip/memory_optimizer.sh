#!/system/bin/sh
# ============================================================================
# Memory Optimizer - LPDDR5 / SM7475
# Author: jtapzg
# ============================================================================

MODE="${1:-SYNC_NORMAL}"

w() { [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null; }

case "$MODE" in
    init|SYNC_NORMAL)
        w /proc/sys/vm/swappiness "100"
        w /proc/sys/vm/vfs_cache_pressure "50"
        w /proc/sys/vm/dirty_ratio "30"
        w /proc/sys/vm/dirty_background_ratio "10"
        w /proc/sys/vm/dirty_expire_centisecs "1500"
        w /proc/sys/vm/dirty_writeback_centisecs "3000"
        w /proc/sys/vm/page-cluster "0"
        ;;
    SYNC_IDLE)
        w /proc/sys/vm/swappiness "120"
        w /proc/sys/vm/vfs_cache_pressure "100"
        w /proc/sys/vm/dirty_ratio "20"
        w /proc/sys/vm/dirty_background_ratio "5"
        w /proc/sys/vm/dirty_expire_centisecs "1000"
        w /proc/sys/vm/dirty_writeback_centisecs "2000"
        w /proc/sys/vm/page-cluster "3"
        ;;
    SYNC_COMBAT)
        w /proc/sys/vm/swappiness "60"
        w /proc/sys/vm/vfs_cache_pressure "30"
        w /proc/sys/vm/dirty_ratio "40"
        w /proc/sys/vm/dirty_background_ratio "15"
        w /proc/sys/vm/dirty_expire_centisecs "3000"
        w /proc/sys/vm/dirty_writeback_centisecs "5000"
        w /proc/sys/vm/page-cluster "0"
        w /proc/sys/vm/watermark_boost_factor "0"
        ;;
    SYNC_BERSERK)
        w /proc/sys/vm/swappiness "40"
        w /proc/sys/vm/vfs_cache_pressure "10"
        w /proc/sys/vm/dirty_ratio "50"
        w /proc/sys/vm/dirty_background_ratio "20"
        w /proc/sys/vm/dirty_expire_centisecs "5000"
        w /proc/sys/vm/dirty_writeback_centisecs "10000"
        w /proc/sys/vm/page-cluster "0"
        w /proc/sys/vm/watermark_boost_factor "0"
        w /proc/sys/vm/compaction_proactiveness "0"
        ;;
esac
