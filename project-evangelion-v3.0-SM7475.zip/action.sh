#!/system/bin/sh
# ============================================================================
# Project Evangelion - Action Script (Manual Trigger + Debug Diagnostics)
# Author: jtapzg
# Usage: sh action.sh         -> show status + restart services
#        sh action.sh debug   -> full debug diagnostic output
# ============================================================================

MODPATH="${0%/*}"
SERVICE_SCRIPT="$MODPATH/service.sh"
MODULE_PROP="$MODPATH/module.prop"
BASEDIR="/data/adb/.config/project-evangelion"
STATEDIR="$BASEDIR/state"
LOG="$BASEDIR/eva_debug.log"

version=$(grep "^version=" "$MODULE_PROP" 2>/dev/null | cut -d'=' -f2)
[ -z "$version" ] && version="Unknown"

# ============================================================================
# Debug Diagnostic Mode
# ============================================================================
if [ "$1" = "debug" ]; then
    echo "============================================"
    echo "  EVA Debug Diagnostics v3.0"
    echo "  $(date)"
    echo "============================================"
    echo ""

    # Daemon status
    daemon_pid=$(pgrep -f "eva_sync_engine" 2>/dev/null | head -1)
    if [ -n "$daemon_pid" ]; then
        echo "  Daemon running:    YES (PID: $daemon_pid)"
        daemon_uptime=$(ps -o etime= -p "$daemon_pid" 2>/dev/null | tr -d ' ')
        echo "  Daemon uptime:     ${daemon_uptime:-unknown}"
    else
        echo "  Daemon running:    NO"
    fi
    echo ""

    # EVA sync enabled
    eva_on=$(cat "$BASEDIR/eva_sync_enabled" 2>/dev/null)
    echo "  EVA sync enabled:  ${eva_on:-not set}"

    # State files
    echo ""
    echo "  === State Files ==="
    if [ -d "$STATEDIR" ]; then
        for f in current_mode sync_level current_app cpu_load gpu_load temperature game_engine; do
            val=$(cat "$STATEDIR/$f" 2>/dev/null)
            printf "  %-18s %s\n" "$f:" "${val:-<empty>}"
        done

        # Check freshness of state files
        echo ""
        if [ -f "$STATEDIR/cpu_load" ]; then
            state_age=$(( $(date +%s) - $(stat -c%Y "$STATEDIR/cpu_load" 2>/dev/null || echo 0) ))
            echo "  State age:         ${state_age}s ago"
            if [ "$state_age" -gt 10 ] 2>/dev/null; then
                echo "  WARNING: State files are STALE (>10s old)"
            else
                echo "  State freshness:   OK"
            fi
        else
            echo "  WARNING: cpu_load state file does not exist"
        fi
    else
        echo "  WARNING: State directory does not exist!"
        echo "  Path: $STATEDIR"
    fi

    # System info
    echo ""
    echo "  === Live System Metrics ==="

    # Live CPU
    cpu_line=$(head -1 /proc/stat 2>/dev/null)
    echo "  /proc/stat:        $(echo "$cpu_line" | cut -c1-60)..."

    # Live GPU
    gpu_busy=""
    if [ -f /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage ]; then
        gpu_busy=$(cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null)
        echo "  GPU busy%%:         $gpu_busy (gpu_busy_percentage)"
    elif [ -f /sys/class/kgsl/kgsl-3d0/gpubusy ]; then
        gpu_busy=$(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null)
        echo "  GPU busy:          $gpu_busy (gpubusy)"
    elif [ -f /sys/class/kgsl/kgsl-3d0/devfreq/gpu_load ]; then
        gpu_busy=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/gpu_load 2>/dev/null)
        echo "  GPU load:          $gpu_busy (devfreq/gpu_load)"
    else
        echo "  GPU load:          N/A (no readable GPU sysfs)"
    fi

    # GPU details
    if [ -d /sys/class/kgsl/kgsl-3d0 ]; then
        gpu_freq=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq 2>/dev/null)
        gpu_gov=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null)
        gpu_bus=$(cat /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null)
        gpu_clk=$(cat /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null)
        gpu_rail=$(cat /sys/class/kgsl/kgsl-3d0/force_rail_on 2>/dev/null)
        echo "  GPU freq:          ${gpu_freq:-N/A}"
        echo "  GPU governor:      ${gpu_gov:-N/A}"
        echo "  GPU force_bus_on:  ${gpu_bus:-N/A}"
        echo "  GPU force_clk_on:  ${gpu_clk:-N/A}"
        echo "  GPU force_rail_on: ${gpu_rail:-N/A}"
    fi

    # Live temperature
    echo ""
    echo "  === Thermal Zones (top 5) ==="
    max_temp=0
    for tz in /sys/class/thermal/thermal_zone*/temp; do
        [ -f "$tz" ] || continue
        t=$(cat "$tz" 2>/dev/null)
        [ -z "$t" ] && continue
        [ "$t" -lt 0 ] 2>/dev/null && continue
        [ "$t" -gt 1000 ] 2>/dev/null && t=$((t / 1000))
        if [ "$t" -gt "$max_temp" ] 2>/dev/null && [ "$t" -lt 120 ] 2>/dev/null; then
            max_temp="$t"
        fi
    done
    echo "  Max temperature:   ${max_temp}C"

    # CPU governors
    echo ""
    echo "  === CPU Governors ==="
    for policy in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
        [ -f "$policy" ] || continue
        pname=$(echo "$policy" | sed 's|.*cpufreq/||;s|/scaling_governor||')
        gov=$(cat "$policy" 2>/dev/null)
        freq=$(cat "$(dirname "$policy")/scaling_cur_freq" 2>/dev/null)
        echo "  $pname: $gov @ ${freq:-?} kHz"
    done

    # Scheduler latency
    echo ""
    echo "  === Scheduler ==="
    for param in sched_latency_ns sched_min_granularity_ns sched_wakeup_granularity_ns sched_migration_cost_ns sched_nr_migrate; do
        val=$(cat "/proc/sys/kernel/$param" 2>/dev/null)
        printf "  %-30s %s\n" "$param:" "${val:-N/A}"
    done

    # Last log lines
    echo ""
    echo "  === Last 15 Log Lines ==="
    if [ -f "$LOG" ]; then
        tail -15 "$LOG" 2>/dev/null | while read -r line; do
            echo "  $line"
        done
    else
        echo "  (no log file found at $LOG)"
    fi

    echo ""
    echo "============================================"
    exit 0
fi

# ============================================================================
# Normal Mode - Show status and restart services
# ============================================================================
echo "============================================"
echo "  Project Evangelion v${version}"
echo "  Author: jtapzg"
echo "  Device: Poco F5 (SM7475)"
echo "============================================"
echo ""

if [ -d "$STATEDIR" ]; then
    current_mode=$(cat "$STATEDIR/current_mode" 2>/dev/null)
    sync_level=$(cat "$STATEDIR/sync_level" 2>/dev/null)
    current_app=$(cat "$STATEDIR/current_app" 2>/dev/null)
    cpu_load=$(cat "$STATEDIR/cpu_load" 2>/dev/null)
    gpu_load=$(cat "$STATEDIR/gpu_load" 2>/dev/null)
    temp=$(cat "$STATEDIR/temperature" 2>/dev/null)
    engine=$(cat "$STATEDIR/game_engine" 2>/dev/null)

    # Check daemon status
    daemon_pid=$(pgrep -f "eva_sync_engine" 2>/dev/null | head -1)

    echo "  === Sincronizacao EVA ==="
    echo ""
    echo "  Daemon:            $([ -n "$daemon_pid" ] && echo "ATIVO (PID: $daemon_pid)" || echo "INATIVO")"
    echo "  Modo atual:        ${current_mode:-N/A}"
    echo "  Nivel de sync:     ${sync_level:-0}%"
    echo "  App ativo:         ${current_app:-N/A}"
    echo "  Carga CPU:         ${cpu_load:-0}%"
    echo "  Carga GPU:         ${gpu_load:-0}%"
    echo "  Temperatura:       ${temp:-0}C"
    [ -n "$engine" ] && [ "$engine" != "unknown" ] && echo "  Engine detectada:  $engine"
    echo ""
fi

BOARD_PLATFORM=$(getprop ro.board.platform | tr '[:lower:]' '[:upper:]')
echo "  === Sistema ==="
echo ""
echo "  Plataforma:        $BOARD_PLATFORM"

if [ -d "/data/adb/ksu" ]; then
    echo "  Root:              KernelSU"
elif [ -d "/data/adb/magisk" ]; then
    echo "  Root:              Magisk"
elif [ -d "/data/adb/ap" ]; then
    echo "  Root:              APatch"
fi

if [ -d /sys/class/kgsl/kgsl-3d0 ]; then
    gpu_freq=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq 2>/dev/null)
    gpu_gov=$(cat /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null)
    echo "  GPU Freq:          ${gpu_freq:-N/A}"
    echo "  GPU Governor:      ${gpu_gov:-N/A}"
fi

cpu_gov=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)
echo "  CPU Governor:      ${cpu_gov:-N/A}"

echo ""
echo "  Dica: use 'sh action.sh debug' para diagnostico completo"
echo ""
echo "============================================"
echo ""

sleep 2

echo "- Reiniciando servicos do Project Evangelion..."
echo ""

if [ -f "$SERVICE_SCRIPT" ]; then
    sh "$SERVICE_SCRIPT" &
    echo "- Servico reiniciado!"
    echo "- Aguarde a notificacao do Projeto EVANGELION."
else
    echo "! service.sh nao encontrado."
fi

echo ""

RAND=$((RANDOM % 7))
case $RAND in
    0) echo "  \"Supere seus limites.\"" ;;
    1) echo "  \"Sincronizacao EVA estavel.\"" ;;
    2) echo "  \"Modo EVA ativado.\"" ;;
    3) echo "  \"Limite de desempenho removido.\"" ;;
    4) echo "  \"Evolucao iniciada.\"" ;;
    5) echo "  \"Sincronizacao piloto-sistema completa.\"" ;;
    6) echo "  \"Despertar do EVA completo.\"" ;;
esac

echo ""
exit 0
