#!/system/bin/sh
# ============================================================================
# Project Evangelion - Main Service Script
# Author: jtapzg
# Optimized for Poco F5 (SM7475 / Snapdragon 7+ Gen 2)
# Runs at boot after system is ready
# ============================================================================

ROOT_METHOD="Unknown"
ROOT_VERSION="Unknown"
BOARD_PLATFORM="Unknown"

# ============================================================================
# Detect root method
# ============================================================================
if [ -d "/data/adb/ksu" ]; then
    ROOT_METHOD="KernelSU"
    ROOT_VERSION=$(cat /data/adb/ksu/version 2>/dev/null || echo "Unknown")
elif [ -d "/data/adb/magisk" ]; then
    ROOT_METHOD="Magisk"
    if command -v magisk >/dev/null 2>&1; then
        ROOT_VERSION=$(magisk -V 2>/dev/null || echo "Unknown")
    fi
elif [ -d "/data/adb/ap" ]; then
    ROOT_METHOD="APatch"
    ROOT_VERSION=$(cat /data/adb/ap/version 2>/dev/null || echo "Unknown")
fi

BOARD_PLATFORM=$(getprop ro.board.platform 2>/dev/null | tr '[:lower:]' '[:upper:]')

MODDIR="/data/adb/modules/project-evangelion"
MODULE_PROP="${MODDIR}/module.prop"
BACKUP_PROP="${MODULE_PROP}.orig"
BASEDIR="/data/adb/.config/project-evangelion"
ICON="file:///data/local/tmp/idk.png"

# SM7475 CPU Topology: 4x A510 little (0-3) + 3x A715 big (4-6) + 1x A715 prime (7)
LITTLE_CORES="0 1 2 3"
BIG_CORES="4 5 6"
PRIME_CORE="7"

w() { [ -f "$1" ] && echo "$2" > "$1" 2>/dev/null; }

# ============================================================================
# Backup and update module description
# ============================================================================
if [ -f "$MODULE_PROP" ] && [ ! -f "$BACKUP_PROP" ]; then
    cp "$MODULE_PROP" "$BACKUP_PROP" 2>/dev/null
fi

if [ -f "$MODULE_PROP" ]; then
    sed -i "s/^description=.*/description=[ Project Evangelion em ${BOARD_PLATFORM} | ${ROOT_METHOD} (${ROOT_VERSION}) ] Modulo de performance Snapdragon 7+ Gen 2 | Author: jtapzg/" "$MODULE_PROP" 2>/dev/null
fi

# ============================================================================
# Wait for boot to complete (with timeout to prevent infinite hang)
# ============================================================================
boot_wait=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
    sleep 5
    boot_wait=$((boot_wait + 5))
    [ "$boot_wait" -ge 120 ] && break
done

# Extra delay to let system stabilize
sleep 10

# ============================================================================
# Ensure config directory exists
# ============================================================================
mkdir -p "$BASEDIR/state" 2>/dev/null
chmod 755 "$BASEDIR" 2>/dev/null
chmod 755 "$BASEDIR/state" 2>/dev/null

# ============================================================================
# Copy perflist and gov.conf to config dir if not there
# ============================================================================
[ ! -f "$BASEDIR/perflist.txt" ] && [ -f "$MODDIR/perflist.txt" ] && cp "$MODDIR/perflist.txt" "$BASEDIR/perflist.txt" 2>/dev/null
[ ! -f "$BASEDIR/gov.conf" ] && [ -f "$MODDIR/gov.conf" ] && cp "$MODDIR/gov.conf" "$BASEDIR/gov.conf" 2>/dev/null

# ============================================================================
# Copy icon for toast notifications
# ============================================================================
[ -f "$MODDIR/idk.png" ] && cp "$MODDIR/idk.png" /data/local/tmp/idk.png 2>/dev/null

# ============================================================================
# Enable EVA features via config files
# ============================================================================
[ ! -f "$BASEDIR/eva_sync_enabled" ] && echo "1" > "$BASEDIR/eva_sync_enabled" 2>/dev/null
[ ! -f "$BASEDIR/sfopt_enabled" ] && echo "1" > "$BASEDIR/sfopt_enabled" 2>/dev/null
[ ! -f "$BASEDIR/preload_enabled" ] && echo "1" > "$BASEDIR/preload_enabled" 2>/dev/null

# ============================================================================
# Initial notification (toast)
# ============================================================================
RAND_PHRASE=$((RANDOM % 7))
case $RAND_PHRASE in
    0) PHRASE="Supere seus limites." ;;
    1) PHRASE="Sincronizacao EVA estavel." ;;
    2) PHRASE="Modo EVA ativado." ;;
    3) PHRASE="Limite de desempenho removido." ;;
    4) PHRASE="Evolucao iniciada." ;;
    5) PHRASE="Sincronizacao piloto-sistema completa." ;;
    6) PHRASE="Despertar do EVA completo." ;;
esac

su -lp 2000 -c "cmd notification post -t 'Projeto EVANGELION ativo' \
    -i '$ICON' \
    -I '$ICON' \
    'eva_boot' 'Inicializando para $BOARD_PLATFORM (SM7475)... $PHRASE'" > /dev/null 2>&1

# ============================================================================
# GPU Optimization (Adreno 725)
# ============================================================================
if [ -f "$MODDIR/gpu_optimizer.sh" ]; then
    sh "$MODDIR/gpu_optimizer.sh" "apply" 2>/dev/null
fi

# ============================================================================
# Scheduler & I/O & Kernel Optimization (initial)
# ============================================================================
if [ -f "$MODDIR/scheduler_optimizer.sh" ]; then
    sh "$MODDIR/scheduler_optimizer.sh" "init" 2>/dev/null
fi

# ============================================================================
# Memory Optimization (initial)
# ============================================================================
if [ -f "$MODDIR/memory_optimizer.sh" ]; then
    sh "$MODDIR/memory_optimizer.sh" "init" 2>/dev/null
fi

# ============================================================================
# Touch Boost
# ============================================================================
for touch in \
    /sys/module/msm_performance/parameters/touchboost \
    /sys/power/pnpmgr/touch_boost \
    /proc/perfmgr/tchbst/kernel/tb_enable \
    /sys/devices/virtual/touch/touch_boost; do
    [ -w "$touch" ] && echo "1" > "$touch" 2>/dev/null
done

# Goodix touch optimization
for ts_path in /sys/devices/virtual/touch/touch_dev \
               /proc/goodix_ts; do
    if [ -e "$ts_path" ]; then
        w "$ts_path/palm_sensor" "0" 2>/dev/null
    fi
done

# ============================================================================
# sched_lib optimization for games
# ============================================================================
lib_names="com.miHoYo. com.activision. com.garena. com.roblox. com.proxima com.tencent com.epicgames com.dts. UnityMain UnityGfxDeviceW libunity.so libil2cpp.so libfb.so libmain.so libcri_vip_unity.so libopus.so libxlua.so libUE4.so libAsphalt9.so libnative-lib.so libRiotGamesApi.so libResources.so libagame.so libapp.so libflutter.so libMSDKCore.so libFIFAMobileNeon.so libUnreal.so libEOSSDK.so libcocos2dcpp.so libgodot_android.so libgdx.so libgdx-box2d.so libminecraftpe.so libLive2DCubismCore.so libyuzu-android.so libryujinx.so libcitra-android.so libhdr_pro_engine.so libandroidx.graphics.path.so libeffect.so"

for path in /proc/sys/kernel/sched_lib_name /proc/sys/kernel/sched_lib_mask_force /proc/sys/walt/sched_lib_name /proc/sys/walt/sched_lib_mask_force; do
    if [ -w "$path" ]; then
        if echo "$path" | grep -q "sched_lib_name"; then
            echo "$lib_names" > "$path" 2>/dev/null
        elif echo "$path" | grep -q "sched_lib_mask_force"; then
            echo "255" > "$path" 2>/dev/null
        fi
    fi
done

# ============================================================================
# SM7475-specific kernel tuning
# ============================================================================
# WALT scheduler
w /proc/sys/kernel/sched_latency_ns "4000000"
w /proc/sys/kernel/sched_min_granularity_ns "500000"
w /proc/sys/kernel/sched_wakeup_granularity_ns "2000000"
w /proc/sys/kernel/sched_migration_cost_ns "250000"
w /proc/sys/kernel/sched_nr_migrate "32"
w /proc/sys/kernel/sched_child_runs_first "1"
w /proc/sys/kernel/sched_tunable_scaling "0"
w /proc/sys/kernel/sched_autogroup_enabled "1"

# WALT-specific
for f in /proc/sys/walt/sched_boost /proc/sys/walt/input_boost/input_boost_ms; do
    w "$f" "0"
done
w /proc/sys/walt/sched_conservative_pl "0"

# Per-cluster CPU governor setup
for cpu in $LITTLE_CORES; do
    cpupath="/sys/devices/system/cpu/cpu$cpu/cpufreq"
    [ -d "$cpupath" ] || continue
    avail=$(cat "$cpupath/scaling_available_governors" 2>/dev/null)
    echo "$avail" | grep -q "schedutil" && w "$cpupath/scaling_governor" "schedutil"
    sp="$cpupath/schedutil"
    if [ -d "$sp" ]; then
        w "$sp/rate_limit_us" "500"
        w "$sp/hispeed_load" "80"
        w "$sp/up_rate_limit_us" "500"
        w "$sp/down_rate_limit_us" "2000"
    fi
done

for cpu in $BIG_CORES $PRIME_CORE; do
    cpupath="/sys/devices/system/cpu/cpu$cpu/cpufreq"
    [ -d "$cpupath" ] || continue
    avail=$(cat "$cpupath/scaling_available_governors" 2>/dev/null)
    echo "$avail" | grep -q "schedutil" && w "$cpupath/scaling_governor" "schedutil"
    sp="$cpupath/schedutil"
    if [ -d "$sp" ]; then
        w "$sp/rate_limit_us" "500"
        w "$sp/hispeed_load" "75"
        w "$sp/up_rate_limit_us" "500"
        w "$sp/down_rate_limit_us" "1000"
    fi
done

# Thermal smoothing
[ -w /sys/class/thermal/thermal_message/sconfig ] && echo "10" > /sys/class/thermal/thermal_message/sconfig 2>/dev/null

# Kernel panic prevention
[ -w /proc/sys/kernel/panic ] && echo "0" > /proc/sys/kernel/panic 2>/dev/null
[ -w /proc/sys/kernel/panic_on_warn ] && echo "0" > /proc/sys/kernel/panic_on_warn 2>/dev/null
[ -w /proc/sys/kernel/panic_on_oops ] && echo "0" > /proc/sys/kernel/panic_on_oops 2>/dev/null
[ -w /proc/sys/kernel/softlockup_panic ] && echo "0" > /proc/sys/kernel/softlockup_panic 2>/dev/null

# Kernel overhead reduction
w /proc/sys/kernel/sched_schedstats "0"
w /proc/sys/kernel/perf_event_paranoid "3"
w /proc/sys/kernel/perf_cpu_time_max_percent "5"
w /proc/sys/kernel/printk "0 0 0 0"
w /proc/sys/kernel/printk_devkmsg "off"
w /sys/kernel/tracing/tracing_on "0" 2>/dev/null
w /sys/kernel/debug/tracing/tracing_on "0" 2>/dev/null

# ============================================================================
# Network Optimizations (enhanced for SM7475)
# ============================================================================
[ -w /proc/sys/net/ipv4/tcp_congestion_control ] && echo "bbr" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
[ -w /proc/sys/net/core/rmem_default ] && echo "1048576" > /proc/sys/net/core/rmem_default 2>/dev/null
[ -w /proc/sys/net/core/wmem_default ] && echo "1048576" > /proc/sys/net/core/wmem_default 2>/dev/null
[ -w /proc/sys/net/core/rmem_max ] && echo "16777216" > /proc/sys/net/core/rmem_max 2>/dev/null
[ -w /proc/sys/net/core/wmem_max ] && echo "16777216" > /proc/sys/net/core/wmem_max 2>/dev/null
[ -w /proc/sys/net/core/optmem_max ] && echo "65536" > /proc/sys/net/core/optmem_max 2>/dev/null
[ -w /proc/sys/net/core/somaxconn ] && echo "512" > /proc/sys/net/core/somaxconn 2>/dev/null
[ -w /proc/sys/net/core/netdev_max_backlog ] && echo "16384" > /proc/sys/net/core/netdev_max_backlog 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_rmem ] && echo "4096 1048576 16777216" > /proc/sys/net/ipv4/tcp_rmem 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_wmem ] && echo "4096 1048576 16777216" > /proc/sys/net/ipv4/tcp_wmem 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_window_scaling ] && echo "1" > /proc/sys/net/ipv4/tcp_window_scaling 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_moderate_rcvbuf ] && echo "1" > /proc/sys/net/ipv4/tcp_moderate_rcvbuf 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_sack ] && echo "1" > /proc/sys/net/ipv4/tcp_sack 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_syncookies ] && echo "1" > /proc/sys/net/ipv4/tcp_syncookies 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_fastopen ] && echo "3" > /proc/sys/net/ipv4/tcp_fastopen 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_tw_reuse ] && echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_ecn ] && echo "1" > /proc/sys/net/ipv4/tcp_ecn 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_timestamps ] && echo "1" > /proc/sys/net/ipv4/tcp_timestamps 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_fin_timeout ] && echo "15" > /proc/sys/net/ipv4/tcp_fin_timeout 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_keepalive_time ] && echo "300" > /proc/sys/net/ipv4/tcp_keepalive_time 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_keepalive_intvl ] && echo "30" > /proc/sys/net/ipv4/tcp_keepalive_intvl 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_keepalive_probes ] && echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_max_syn_backlog ] && echo "2048" > /proc/sys/net/ipv4/tcp_max_syn_backlog 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_slow_start_after_idle ] && echo "0" > /proc/sys/net/ipv4/tcp_slow_start_after_idle 2>/dev/null
[ -w /proc/sys/net/ipv4/tcp_no_metrics_save ] && echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save 2>/dev/null
[ -w /proc/sys/net/core/default_qdisc ] && echo "fq" > /proc/sys/net/core/default_qdisc 2>/dev/null

# ============================================================================
# I/O Scheduler (UFS 3.1)
# ============================================================================
for blk in /sys/block/sd*/queue /sys/block/dm-*/queue; do
    [ -d "$blk" ] || continue
    avail=$(cat "$blk/scheduler" 2>/dev/null)
    echo "$avail" | grep -q "mq-deadline" && w "$blk/scheduler" "mq-deadline"
    w "$blk/read_ahead_kb" "128"
    w "$blk/nr_requests" "128"
    w "$blk/iostats" "0"
    w "$blk/add_random" "0"
    w "$blk/nomerges" "0"
    w "$blk/rq_affinity" "2"
    w "$blk/rotational" "0"
done

# ============================================================================
# IRQ Affinity for SM7475 (1+3+4 topology)
# ============================================================================
# Pin display/GPU IRQs to performance cores
for irq_name in kgsl mdss msm_drm; do
    for irq in $(grep "$irq_name" /proc/interrupts 2>/dev/null | awk -F: '{print $1}' | tr -d ' '); do
        [ -f "/proc/irq/$irq/smp_affinity" ] && echo "f0" > "/proc/irq/$irq/smp_affinity" 2>/dev/null
    done
done
# Pin touch IRQs to prime core
for irq_name in goodix fts_ts; do
    for irq in $(grep "$irq_name" /proc/interrupts 2>/dev/null | awk -F: '{print $1}' | tr -d ' '); do
        [ -f "/proc/irq/$irq/smp_affinity" ] && echo "80" > "/proc/irq/$irq/smp_affinity" 2>/dev/null
    done
done

# ============================================================================
# Memory Optimization (initial)
# ============================================================================
w /proc/sys/vm/swappiness "100"
w /proc/sys/vm/vfs_cache_pressure "50"
w /proc/sys/vm/dirty_ratio "30"
w /proc/sys/vm/dirty_background_ratio "10"
w /proc/sys/vm/dirty_expire_centisecs "1500"
w /proc/sys/vm/dirty_writeback_centisecs "3000"
w /proc/sys/vm/page-cluster "0"
w /proc/sys/vm/overcommit_memory "1"
w /proc/sys/vm/min_free_kbytes "16384"
w /proc/sys/vm/extra_free_kbytes "24576"
w /proc/sys/vm/watermark_boost_factor "0"
w /proc/sys/vm/compaction_proactiveness "0"

# ZRAM optimization (lz4 for speed on SM7475)
TOTAL_RAM=$(awk '/MemTotal/{print $2}' /proc/meminfo)
ZRAM_SIZE=$((TOTAL_RAM / 2))
if [ -b /dev/block/zram0 ]; then
    swapoff /dev/block/zram0 2>/dev/null
    w /sys/block/zram0/reset "1"
    w /sys/block/zram0/comp_algorithm "lz4"
    w /sys/block/zram0/disksize "${ZRAM_SIZE}K"
    mkswap /dev/block/zram0 2>/dev/null
    swapon /dev/block/zram0 -p 32767 2>/dev/null
fi

# ============================================================================
# Runtime display properties
# ============================================================================
setprop debug.sf.hw 1 2>/dev/null
setprop debug.egl.hw 1 2>/dev/null
setprop debug.sf.showfps 0 2>/dev/null
setprop debug.sf.showcpu 0 2>/dev/null
setprop debug.sf.showupdates 0 2>/dev/null
setprop debug.hwui.renderer skiagl 2>/dev/null
setprop debug.performance.tuning 1 2>/dev/null
setprop debug.sf.showbackground 0 2>/dev/null
setprop debug.hwui.skip_empty_damage true 2>/dev/null
setprop debug.hwui.use_hint_manager true 2>/dev/null
setprop debug.hwui.target_cpu_time_percent 30 2>/dev/null
setprop debug.renderengine.backend skiaglthreaded 2>/dev/null

# Binder thread optimization
setprop debug.binder.executor.threads 32 2>/dev/null
setprop debug.binder.max_threads 32 2>/dev/null

# ART optimization
setprop dalvik.vm.dex2oat-threads 8 2>/dev/null
setprop dalvik.vm.image-dex2oat-threads 8 2>/dev/null

# ============================================================================
# FSTRIM (background, non-blocking)
# ============================================================================
(
    sleep 30
    for partition in /data /cache /system /vendor; do
        fstrim "$partition" 2>/dev/null
    done
) &

# ============================================================================
# Launch SurfaceFlinger Optimizer
# ============================================================================
sfopt_enabled=$(cat "$BASEDIR/sfopt_enabled" 2>/dev/null)
if [ "$sfopt_enabled" = "1" ] && [ -f "$MODDIR/sfopt.sh" ]; then
    sh "$MODDIR/sfopt.sh" &
fi

# ============================================================================
# Launch EVA Sync Engine (primary) or fallback govpreload
# nohup ensures daemon persists after boot completes
# ============================================================================
eva_enabled=$(cat "$BASEDIR/eva_sync_enabled" 2>/dev/null)
if [ "$eva_enabled" = "1" ] && [ -f "$MODDIR/eva_sync_engine.sh" ]; then
    # Kill any existing daemon before restarting
    for pid in $(pgrep -f "eva_sync_engine" 2>/dev/null); do
        [ "$pid" != "$$" ] && kill "$pid" 2>/dev/null
    done
    sleep 1
    nohup sh "$MODDIR/eva_sync_engine.sh" >/dev/null 2>&1 &
elif [ -f "$MODDIR/govpreload.sh" ]; then
    nohup sh "$MODDIR/govpreload.sh" >/dev/null 2>&1 &
fi

# ============================================================================
# Final notification
# ============================================================================
su -lp 2000 -c "cmd notification post -t 'Projeto EVANGELION ativo' \
    -i '$ICON' \
    -I '$ICON' \
    'eva_ready' 'Tweaks aplicados para $BOARD_PLATFORM (SM7475) | $PHRASE'" >/dev/null 2>&1

exit 0
