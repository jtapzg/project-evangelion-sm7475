/* ============================================================================
   Project Evangelion - WebUI Script
   Author: jtapzg
   Optimized for Poco F5 (SM7475 / Snapdragon 7+ Gen 2)
   Fixed: Shell API compatibility for KSU/MMRL/APatch + live data polling
   ============================================================================ */

(function () {
    'use strict';

    var CONFIG = {
        BASEDIR: '/data/adb/.config/project-evangelion',
        STATEDIR: '/data/adb/.config/project-evangelion/state',
        MODDIR: '/data/adb/modules/project-evangelion',
        POLL_INTERVAL: 2000,
        CHART_MAX_POINTS: 40,
        BOOT_DURATION: 4200,
        EXEC_TIMEOUT: 3000
    };

    var ANIME_MESSAGES = [
        'Supere seus limites.',
        'Modo EVA ativado.',
        'Sincronizacao estavel.',
        'Modo Berserk liberado.',
        'Sistema de combate ativado.',
        'Limite de desempenho removido.',
        'Evolucao iniciada.',
        'Sincronizacao piloto-sistema completa.',
        'Potencia maxima liberada.',
        'Sistema neural conectado.',
        'Despertar do EVA completo.'
    ];

    var PRAISE_TEXTS = [
        'Projeto desenvolvido pelo engenheiro de desempenho jtapzg.',
        'O Project Evangelion representa uma nova geracao de otimizacao Android.',
        'Desenvolvimento e arquitetura por jtapzg.'
    ];

    var ENGINE_NAMES = {
        unity: 'UNITY',
        unreal: 'UNREAL',
        godot: 'GODOT',
        cocos: 'COCOS',
        flutter: 'FLUTTER',
        unknown: '---'
    };

    /* ========================================================================
       SHELL EXECUTION LAYER
       Fixed: Full compatibility with KernelSU, Magisk, APatch, MMRL WebUI APIs
       Handles both sync and async exec styles, with timeout protection
       ======================================================================== */
    var Shell = {
        _backend: null,
        _execCount: 0,
        _errorCount: 0,

        init: function() {
            if (typeof ksu !== 'undefined' && typeof ksu.exec === 'function') {
                this._backend = 'ksu';
            } else if (typeof ksu !== 'undefined' && typeof ksu.execCommand === 'function') {
                this._backend = 'ksu_legacy';
            } else if (typeof $mmrl !== 'undefined' && typeof $mmrl.exec === 'function') {
                this._backend = 'mmrl';
            } else if (typeof mmrl !== 'undefined' && typeof mmrl.exec === 'function') {
                this._backend = 'mmrl_alt';
            } else if (typeof apatch !== 'undefined' && typeof apatch.exec === 'function') {
                this._backend = 'apatch';
            } else {
                this._backend = 'demo';
            }
            console.log('[EVA] Shell backend: ' + this._backend);
        },

        exec: function(cmd) {
            var self = this;
            self._execCount++;
            try {
                switch (self._backend) {
                    case 'ksu':        return self._execKsu(cmd);
                    case 'ksu_legacy': return self._execKsuLegacy(cmd);
                    case 'mmrl':       return Promise.resolve(self._execMmrl(cmd));
                    case 'mmrl_alt':   return Promise.resolve(self._execMmrlAlt(cmd));
                    case 'apatch':     return self._execApatch(cmd);
                    default:           return Promise.resolve({ stdout: '', stderr: 'demo', errno: -1 });
                }
            } catch (e) {
                self._errorCount++;
                return Promise.resolve({ stdout: '', stderr: String(e), errno: -1 });
            }
        },

        /* KernelSU: try sync return first, then callback as fallback */
        _execKsu: function(cmd) {
            var self = this;
            return self._withTimeout(new Promise(function(resolve) {
                try {
                    var result = ksu.exec(cmd);
                    /* Promise-based return */
                    if (result && typeof result.then === 'function') {
                        result.then(function(r) {
                            resolve(self._norm(r));
                        })["catch"](function(e) {
                            resolve({ stdout: '', stderr: String(e), errno: -1 });
                        });
                    /* Sync object return { errno, stdout, stderr } */
                    } else if (result && typeof result === 'object') {
                        resolve(self._norm(result));
                    /* Direct string return */
                    } else if (typeof result === 'string') {
                        resolve({ stdout: result, stderr: '', errno: 0 });
                    } else {
                        resolve({ stdout: '', stderr: 'no result', errno: -1 });
                    }
                } catch (err) {
                    /* Fallback: old callback style ksu.exec(cmd, opts, cb) */
                    try {
                        ksu.exec(cmd, '{}', function(out, err2) {
                            resolve({
                                stdout: (typeof out === 'string') ? out : (out && out.stdout) || '',
                                stderr: (typeof err2 === 'string') ? err2 : '',
                                errno: 0
                            });
                        });
                    } catch (e2) {
                        resolve({ stdout: '', stderr: String(err), errno: -1 });
                    }
                }
            }), CONFIG.EXEC_TIMEOUT);
        },

        _execKsuLegacy: function(cmd) {
            var self = this;
            return self._withTimeout(new Promise(function(resolve) {
                try {
                    resolve(self._norm(ksu.execCommand(cmd)));
                } catch (e) {
                    resolve({ stdout: '', stderr: String(e), errno: -1 });
                }
            }), CONFIG.EXEC_TIMEOUT);
        },

        _execMmrl: function(cmd) {
            try {
                var r = $mmrl.exec(cmd);
                return (typeof r === 'string') ? { stdout: r, stderr: '', errno: 0 } : this._norm(r);
            } catch (e) {
                return { stdout: '', stderr: String(e), errno: -1 };
            }
        },

        _execMmrlAlt: function(cmd) {
            try {
                var r = mmrl.exec(cmd);
                return (typeof r === 'string') ? { stdout: r, stderr: '', errno: 0 } : this._norm(r);
            } catch (e) {
                return { stdout: '', stderr: String(e), errno: -1 };
            }
        },

        _execApatch: function(cmd) {
            var self = this;
            return self._withTimeout(new Promise(function(resolve) {
                try {
                    var r = apatch.exec(cmd);
                    if (r && typeof r.then === 'function') {
                        r.then(function(v) { resolve(self._norm(v)); })
                         ["catch"](function(e) { resolve({ stdout: '', stderr: String(e), errno: -1 }); });
                    } else {
                        resolve(self._norm(r));
                    }
                } catch (e) {
                    resolve({ stdout: '', stderr: String(e), errno: -1 });
                }
            }), CONFIG.EXEC_TIMEOUT);
        },

        /* Normalize any result format */
        _norm: function(r) {
            if (!r) return { stdout: '', stderr: '', errno: -1 };
            if (typeof r === 'string') return { stdout: r, stderr: '', errno: 0 };
            return {
                stdout: (r.stdout || r.out || r.output || '').toString(),
                stderr: (r.stderr || r.err || r.error || '').toString(),
                errno: (typeof r.errno === 'number') ? r.errno : (typeof r.code === 'number') ? r.code : 0
            };
        },

        /* Timeout wrapper to prevent hung promises */
        _withTimeout: function(promise, ms) {
            return new Promise(function(resolve) {
                var t = setTimeout(function() {
                    resolve({ stdout: '', stderr: 'timeout', errno: -2 });
                }, ms);
                promise.then(function(r) { clearTimeout(t); resolve(r); })
                       ["catch"](function(e) { clearTimeout(t); resolve({ stdout: '', stderr: String(e), errno: -1 }); });
            });
        },

        /* Batch read multiple files in one shell call */
        readFiles: function(paths) {
            var cmd = paths.map(function(p) {
                return 'cat "' + p + '" 2>/dev/null || echo ""';
            }).join('; echo "___SEP___"; ');
            return this.exec(cmd).then(function(r) {
                var out = r.stdout || '';
                if (!out && r.errno !== 0) return paths.map(function() { return ''; });
                var parts = out.split('___SEP___');
                return paths.map(function(_, i) { return (parts[i] || '').trim(); });
            });
        },

        readFile: function(path) {
            return this.exec('cat "' + path + '" 2>/dev/null').then(function(r) {
                return (r.stdout || '').trim();
            });
        },

        writeFile: function(path, value) {
            return this.exec('echo "' + value + '" > "' + path + '"');
        },

        isDemo: function() { return this._backend === 'demo'; },

        getStats: function() {
            return { backend: this._backend, calls: this._execCount, errors: this._errorCount };
        }
    };

    /* ========================================================================
       STATE
       ======================================================================== */
    var State = {
        syncLevel: 0, currentMode: 'SYNC_IDLE',
        cpuLoad: 0, gpuLoad: 0, temperature: 0,
        currentApp: '---', gameEngine: 'unknown', detectedGame: 'Nenhum',
        cpuHistory: [], gpuHistory: [], tempHistory: [],
        evaSyncEnabled: true, gpuBoost: true, shaderPreload: true,
        touchBoost: true, irqBalance: true, sfopt: true,
        manualMode: 'AUTO', praiseIndex: 0,
        pollErrors: 0, lastPollOk: false
    };

    var DOM = {};

    function cacheDom() {
        var g = function(id) { return document.getElementById(id); };
        DOM = {
            bootScreen: g('boot-screen'),
            mainInterface: g('main-interface'),
            bootLines: document.querySelectorAll('.boot-line'),
            bootProgressBar: document.querySelector('.boot-progress-bar'),
            headerTime: g('header-time'),
            animeBanner: g('anime-banner'),
            animeMessage: g('anime-message'),
            syncPanel: g('sync-panel'),
            syncRingFill: g('sync-ring-fill'),
            syncPercent: g('sync-percent'),
            syncMode: g('sync-mode'),
            syncBarFill: g('sync-bar-fill'),
            syncBarGlow: g('sync-bar-glow'),
            currentApp: g('current-app'),
            temperature: g('temperature'),
            cpuBar: g('cpu-bar'), cpuValue: g('cpu-value'),
            gpuBar: g('gpu-bar'), gpuValue: g('gpu-value'),
            tempBar: g('temp-bar'), tempValue: g('temp-value'),
            perfChart: g('perfChart'),
            radarDot: g('radar-dot'),
            detectedGame: g('detected-game'),
            detectedEngine: g('detected-engine'),
            gameStatus: g('game-status'),
            gameMessage: g('game-message'),
            toggleEvaSync: g('toggle-eva-sync'),
            toggleGpuBoost: g('toggle-gpu-boost'),
            toggleShaderPreload: g('toggle-shader-preload'),
            toggleTouchBoost: g('toggle-touch-boost'),
            toggleIrqBalance: g('toggle-irq-balance'),
            toggleSfopt: g('toggle-sfopt'),
            modeAuto: g('mode-auto'), modeNormal: g('mode-normal'),
            modeCombat: g('mode-combat'), modeBerserk: g('mode-berserk'),
            praiseText: g('praise-text'),
            footerStatus: g('footer-status')
        };
    }

    /* ========================================================================
       BOOT SEQUENCE
       ======================================================================== */
    function runBootSequence() {
        var lines = DOM.bootLines;
        var bar = DOM.bootProgressBar;
        var dur = CONFIG.BOOT_DURATION;
        var t0 = Date.now();

        lines.forEach(function(l) {
            var d = parseInt(l.dataset.delay, 10) || 0;
            setTimeout(function() { l.classList.add('visible'); }, d);
        });

        function tick() {
            var pct = Math.min(((Date.now() - t0) / dur) * 100, 100);
            bar.style.width = pct + '%';
            if (pct < 100) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);

        setTimeout(function() {
            DOM.bootScreen.classList.add('fade-out');
            setTimeout(function() {
                DOM.bootScreen.style.display = 'none';
                DOM.mainInterface.classList.remove('hidden');
                startMainLoop();
            }, 800);
        }, dur);
    }

    /* ========================================================================
       CLOCK & MESSAGES
       ======================================================================== */
    function updateClock() {
        var d = new Date();
        var s = [d.getHours(), d.getMinutes(), d.getSeconds()]
            .map(function(v) { return String(v).padStart(2, '0'); }).join(':');
        if (DOM.headerTime) DOM.headerTime.textContent = s;
    }

    function startAnimeMessages() {
        changeAnimeMessage();
        setInterval(changeAnimeMessage, 8000);
    }

    function changeAnimeMessage() {
        var msg = ANIME_MESSAGES[Math.floor(Math.random() * ANIME_MESSAGES.length)];
        if (DOM.animeMessage) {
            DOM.animeMessage.style.opacity = '0';
            setTimeout(function() {
                DOM.animeMessage.textContent = msg;
                DOM.animeMessage.style.opacity = '1';
            }, 300);
        }
    }

    function startPraiseRotation() {
        if (!DOM.praiseText) return;
        setInterval(function() {
            State.praiseIndex = (State.praiseIndex + 1) % PRAISE_TEXTS.length;
            DOM.praiseText.style.opacity = '0';
            setTimeout(function() {
                DOM.praiseText.textContent = PRAISE_TEXTS[State.praiseIndex];
                DOM.praiseText.style.opacity = '0.8';
            }, 500);
        }, 6000);
    }

    /* ========================================================================
       CHART
       ======================================================================== */
    var perfChart;

    function initChart() {
        if (!DOM.perfChart) return;
        var ctx = DOM.perfChart.getContext('2d');
        perfChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    { label: 'CPU %', data: [], borderColor: '#39ff14',
                      backgroundColor: 'rgba(57,255,20,0.08)', borderWidth: 1.5,
                      pointRadius: 0, tension: 0.3, fill: true },
                    { label: 'GPU %', data: [], borderColor: '#a855f7',
                      backgroundColor: 'rgba(168,85,247,0.08)', borderWidth: 1.5,
                      pointRadius: 0, tension: 0.3, fill: true },
                    { label: 'Temp C', data: [], borderColor: '#ff6600',
                      backgroundColor: 'rgba(255,102,0,0.05)', borderWidth: 1.5,
                      pointRadius: 0, tension: 0.3, fill: false }
                ]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                animation: { duration: 400 },
                plugins: { legend: { display: true, position: 'top',
                    labels: { color: '#8888aa',
                        font: { family: "'Share Tech Mono', monospace", size: 10 },
                        boxWidth: 12, padding: 8 } } },
                scales: {
                    x: { display: false },
                    y: { min: 0, max: 100,
                        grid: { color: 'rgba(123,47,190,0.1)', drawBorder: false },
                        ticks: { color: '#555',
                            font: { family: "'Share Tech Mono', monospace", size: 9 },
                            stepSize: 25 } }
                }
            }
        });
    }

    function updateChart() {
        if (!perfChart) return;
        var d = new Date();
        var lbl = String(d.getMinutes()).padStart(2,'0') + ':' + String(d.getSeconds()).padStart(2,'0');
        perfChart.data.labels.push(lbl);
        perfChart.data.datasets[0].data.push(State.cpuLoad);
        perfChart.data.datasets[1].data.push(State.gpuLoad);
        perfChart.data.datasets[2].data.push(State.temperature);
        if (perfChart.data.labels.length > CONFIG.CHART_MAX_POINTS) {
            perfChart.data.labels.shift();
            perfChart.data.datasets.forEach(function(ds) { ds.data.shift(); });
        }
        perfChart.update('none');
    }

    /* ========================================================================
       UI UPDATES
       ======================================================================== */
    function updateSyncGauge() {
        var pct = State.syncLevel;
        var circ = 2 * Math.PI * 85;
        var off = circ - (pct / 100) * circ;
        if (DOM.syncRingFill) DOM.syncRingFill.style.strokeDashoffset = off;
        if (DOM.syncPercent) animateNumber(DOM.syncPercent, pct);
        if (DOM.syncBarFill) DOM.syncBarFill.style.width = pct + '%';
        if (DOM.syncBarGlow) DOM.syncBarGlow.style.width = pct + '%';
    }

    function animateNumber(el, target) {
        if (!el) return;
        var cur = parseInt(el.textContent, 10) || 0;
        if (cur === target) return;
        var diff = target - cur, steps = 15, sv = diff / steps, s = 0;
        var iv = setInterval(function() {
            s++;
            el.textContent = Math.round(cur + sv * s);
            if (s >= steps) { el.textContent = target; clearInterval(iv); }
        }, 25);
    }

    function updateSyncMode() {
        var m = State.currentMode;
        if (DOM.syncMode) { DOM.syncMode.textContent = m; DOM.syncMode.className = 'sync-mode-value'; }
        if (DOM.syncPanel) DOM.syncPanel.className = 'hud-panel sync-panel';
        var cls = { SYNC_IDLE: 'idle', SYNC_NORMAL: 'normal', SYNC_COMBAT: 'combat', SYNC_BERSERK: 'berserk' };
        var c = cls[m];
        if (c) {
            if (DOM.syncMode) DOM.syncMode.classList.add('mode-' + c);
            if (DOM.syncPanel) DOM.syncPanel.classList.add('sync-' + c);
        }
    }

    function updatePerformanceBars() {
        var cpu = State.cpuLoad, gpu = State.gpuLoad, temp = State.temperature;
        if (DOM.cpuBar) DOM.cpuBar.style.width = Math.min(cpu, 100) + '%';
        if (DOM.cpuValue) DOM.cpuValue.textContent = cpu + '%';
        if (DOM.gpuBar) DOM.gpuBar.style.width = Math.min(gpu, 100) + '%';
        if (DOM.gpuValue) DOM.gpuValue.textContent = gpu + '%';
        var tp = Math.min((temp / 60) * 100, 100);
        if (DOM.tempBar) DOM.tempBar.style.width = tp + '%';
        if (DOM.tempValue) DOM.tempValue.textContent = temp + '\u00B0C';
        if (DOM.temperature) DOM.temperature.textContent = temp + '\u00B0C';
        if (DOM.currentApp) DOM.currentApp.textContent = State.currentApp || '---';
    }

    function updateGameDetection() {
        var eng = State.gameEngine || 'unknown';
        var disp = ENGINE_NAMES[eng] || eng.toUpperCase();
        var game = State.detectedGame || 'Nenhum';
        var isG = eng !== 'unknown' && eng !== '' && game !== 'Nenhum';
        if (DOM.detectedGame) DOM.detectedGame.textContent = game;
        if (DOM.detectedEngine) DOM.detectedEngine.textContent = disp;
        if (isG) {
            if (DOM.radarDot) { DOM.radarDot.classList.add('active');
                DOM.radarDot.style.top = (30 + Math.random() * 40) + '%';
                DOM.radarDot.style.left = (30 + Math.random() * 40) + '%'; }
            if (DOM.gameStatus) { DOM.gameStatus.textContent = 'Jogo detectado!'; DOM.gameStatus.style.color = '#39ff14'; }
            var m1 = DOM.gameMessage ? DOM.gameMessage.querySelector('.game-message-text') : null;
            if (m1) m1.textContent = 'Motor: ' + disp + ' | Perfil aplicado';
        } else {
            if (DOM.radarDot) DOM.radarDot.classList.remove('active');
            if (DOM.gameStatus) { DOM.gameStatus.textContent = 'Aguardando deteccao...'; DOM.gameStatus.style.color = ''; }
            var m2 = DOM.gameMessage ? DOM.gameMessage.querySelector('.game-message-text') : null;
            if (m2) m2.textContent = 'Sistema de deteccao ativo';
        }
    }

    function updateFooter() {
        if (!DOM.footerStatus) return;
        var s = Shell.getStats();
        if (Shell.isDemo()) DOM.footerStatus.textContent = 'MODO DEMO';
        else if (State.lastPollOk) DOM.footerStatus.textContent = 'SISTEMA OPERACIONAL | ' + s.backend.toUpperCase();
        else DOM.footerStatus.textContent = 'RECONECTANDO... | ' + s.backend.toUpperCase();
    }

    /* ========================================================================
       DATA POLLING - FIXED: batch reads + error recovery + fallback
       ======================================================================== */
    function pollDeviceState() {
        if (Shell.isDemo()) { pollDemoState(); return Promise.resolve(); }

        var paths = [
            CONFIG.STATEDIR + '/sync_level',
            CONFIG.STATEDIR + '/current_mode',
            CONFIG.STATEDIR + '/cpu_load',
            CONFIG.STATEDIR + '/gpu_load',
            CONFIG.STATEDIR + '/temperature',
            CONFIG.STATEDIR + '/current_app',
            CONFIG.STATEDIR + '/game_engine'
        ];

        return Shell.readFiles(paths).then(function(v) {
            var ok = v[0] || v[1] || v[2] || v[3] || v[4];
            if (ok) {
                State.syncLevel = parseInt(v[0], 10) || State.syncLevel;
                State.currentMode = v[1] || State.currentMode;
                State.cpuLoad = parseInt(v[2], 10) || 0;
                State.gpuLoad = parseInt(v[3], 10) || 0;
                State.temperature = parseInt(v[4], 10) || 0;
                State.currentApp = v[5] || '---';
                State.gameEngine = v[6] || 'unknown';
                State.detectedGame = (State.gameEngine !== 'unknown' && State.gameEngine !== '') ? State.currentApp : 'Nenhum';
                State.lastPollOk = true;
                State.pollErrors = 0;
            } else {
                return pollFallback();
            }
        })["catch"](function(e) {
            console.warn('[EVA] Poll error:', e);
            State.pollErrors++;
            State.lastPollOk = false;
            if (State.pollErrors >= 3) pollDemoState();
        });
    }

    function pollFallback() {
        return Shell.readFile(CONFIG.STATEDIR + '/sync_level').then(function(v) {
            State.syncLevel = parseInt(v, 10) || State.syncLevel;
            return Shell.readFile(CONFIG.STATEDIR + '/current_mode');
        }).then(function(v) {
            State.currentMode = v || State.currentMode;
            return Shell.readFile(CONFIG.STATEDIR + '/cpu_load');
        }).then(function(v) {
            State.cpuLoad = parseInt(v, 10) || 0;
            return Shell.readFile(CONFIG.STATEDIR + '/gpu_load');
        }).then(function(v) {
            State.gpuLoad = parseInt(v, 10) || 0;
            return Shell.readFile(CONFIG.STATEDIR + '/temperature');
        }).then(function(v) {
            State.temperature = parseInt(v, 10) || 0;
            return Shell.readFile(CONFIG.STATEDIR + '/current_app');
        }).then(function(v) {
            State.currentApp = v || '---';
            return Shell.readFile(CONFIG.STATEDIR + '/game_engine');
        }).then(function(v) {
            State.gameEngine = v || 'unknown';
            State.detectedGame = (State.gameEngine !== 'unknown' && State.gameEngine !== '') ? State.currentApp : 'Nenhum';
            State.lastPollOk = true;
            State.pollErrors = 0;
        })["catch"](function(e) {
            State.pollErrors++;
            State.lastPollOk = false;
        });
    }

    /* ========================================================================
       DEMO MODE (fallback when no shell backend)
       ======================================================================== */
    var demoTick = 0;

    function pollDemoState() {
        demoTick++;
        var p1 = (Math.sin(demoTick * 0.05) + 1) / 2;
        var p2 = (Math.sin(demoTick * 0.03 + 1) + 1) / 2;
        State.cpuLoad = Math.max(0, Math.min(100, Math.round(15 + p1 * 70 + (Math.random() * 10 - 5))));
        State.gpuLoad = Math.max(0, Math.min(100, Math.round(10 + p2 * 75 + (Math.random() * 8 - 4))));
        State.temperature = Math.max(20, Math.min(55, Math.round(28 + p1 * 18 + (Math.random() * 3 - 1.5))));

        if (State.manualMode !== 'AUTO') {
            var mm = { NORMAL: [50, 'SYNC_NORMAL'], COMBAT: [78, 'SYNC_COMBAT'], BERSERK: [95, 'SYNC_BERSERK'] };
            var mv = mm[State.manualMode];
            if (mv) { State.syncLevel = mv[0]; State.currentMode = mv[1]; }
        } else {
            var avg = (State.cpuLoad + State.gpuLoad) / 2;
            if (avg >= 80)      { State.syncLevel = Math.round(90 + Math.random() * 10); State.currentMode = 'SYNC_BERSERK'; }
            else if (avg >= 55) { State.syncLevel = Math.round(65 + (avg - 55)); State.currentMode = 'SYNC_COMBAT'; }
            else if (avg >= 25) { State.syncLevel = Math.round(35 + (avg - 25)); State.currentMode = 'SYNC_NORMAL'; }
            else                { State.syncLevel = Math.round(10 + avg); State.currentMode = 'SYNC_IDLE'; }
        }
        State.syncLevel = Math.max(0, Math.min(100, State.syncLevel));

        if (demoTick % 20 < 8 && State.cpuLoad > 50) {
            State.currentApp = 'com.miHoYo.GenshinImpact'; State.gameEngine = 'unity'; State.detectedGame = 'com.miHoYo.GenshinImpact';
        } else if (demoTick % 20 < 14 && State.gpuLoad > 40) {
            State.currentApp = 'com.epicgames.fortnite'; State.gameEngine = 'unreal'; State.detectedGame = 'com.epicgames.fortnite';
        } else {
            State.currentApp = 'com.android.launcher3'; State.gameEngine = 'unknown'; State.detectedGame = 'Nenhum';
        }
    }

    /* ========================================================================
       CONTROLS
       ======================================================================== */
    function setupControls() {
        function tog(el, key, file) {
            if (!el) return;
            el.addEventListener('change', function() {
                State[key] = this.checked;
                if (!Shell.isDemo() && file) Shell.writeFile(CONFIG.BASEDIR + '/' + file, this.checked ? '1' : '0');
            });
        }
        tog(DOM.toggleEvaSync, 'evaSyncEnabled', 'eva_sync_enabled');
        tog(DOM.toggleSfopt, 'sfopt', 'sfopt_enabled');
        tog(DOM.toggleShaderPreload, 'shaderPreload', 'preload_enabled');

        if (DOM.toggleGpuBoost) {
            DOM.toggleGpuBoost.addEventListener('change', function() {
                State.gpuBoost = this.checked;
                if (!Shell.isDemo() && this.checked) Shell.exec('sh ' + CONFIG.MODDIR + '/gpu_optimizer.sh boost &');
            });
        }
        if (DOM.toggleTouchBoost) DOM.toggleTouchBoost.addEventListener('change', function() { State.touchBoost = this.checked; });
        if (DOM.toggleIrqBalance) DOM.toggleIrqBalance.addEventListener('change', function() { State.irqBalance = this.checked; });

        var btns = document.querySelectorAll('.mode-btn');
        btns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                btns.forEach(function(b) { b.classList.remove('active'); });
                this.classList.add('active');
                var mode = this.dataset.mode;
                State.manualMode = mode;
                if (!Shell.isDemo() && mode !== 'AUTO') {
                    var em = { NORMAL: 'SYNC_NORMAL', COMBAT: 'SYNC_COMBAT', BERSERK: 'SYNC_BERSERK' }[mode];
                    if (!em) return;
                    Shell.writeFile(CONFIG.STATEDIR + '/current_mode', em);
                    Shell.exec('sh ' + CONFIG.MODDIR + '/scheduler_optimizer.sh ' + em + ' &');
                    Shell.exec('sh ' + CONFIG.MODDIR + '/memory_optimizer.sh ' + em + ' &');
                    if (mode === 'COMBAT' || mode === 'BERSERK')
                        Shell.exec('sh ' + CONFIG.MODDIR + '/gpu_optimizer.sh ' + mode.toLowerCase() + ' &');
                }
                changeAnimeMessage();
            });
        });
    }

    /* ========================================================================
       MAIN LOOP - non-blocking, error-resilient
       ======================================================================== */
    var polling = false;

    function mainUpdate() {
        if (polling) return;
        polling = true;
        var p;
        try { p = pollDeviceState(); } catch(e) { polling = false; return; }
        var doUI = function() {
            updateSyncGauge(); updateSyncMode(); updatePerformanceBars();
            updateGameDetection(); updateChart(); updateClock(); updateFooter();
            polling = false;
        };
        if (p && typeof p.then === 'function') {
            p.then(doUI)["catch"](function() { polling = false; });
        } else {
            doUI();
        }
    }

    function startMainLoop() {
        initChart(); setupControls(); startAnimeMessages(); startPraiseRotation();
        mainUpdate();
        setInterval(mainUpdate, CONFIG.POLL_INTERVAL);
        setInterval(updateClock, 1000);
    }

    /* ========================================================================
       INIT
       ======================================================================== */
    document.addEventListener('DOMContentLoaded', function() {
        cacheDom();
        Shell.init();
        runBootSequence();
    });
})();
