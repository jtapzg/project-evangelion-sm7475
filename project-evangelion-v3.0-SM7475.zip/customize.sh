#!/system/bin/sh
# ============================================================================
# Project Evangelion - Installation
# Optimized for Poco F5 (SM7475 / Snapdragon 7+ Gen 2)
# ============================================================================

ui_print "======================================"
ui_print "  PROJECT EVANGELION v2.1-SM7475"
ui_print "  Snapdragon 7+ Gen 2 Edition"
ui_print "  Poco F5 (marble)"
ui_print "======================================"
ui_print ""

DEVICE=$(getprop ro.product.board)
SOC=$(getprop ro.board.platform)
ui_print "  Device Board: $DEVICE"
ui_print "  SoC Platform: $SOC"
ui_print ""

if [ "$DEVICE" != "marble" ] && [ "$DEVICE" != "marblein" ]; then
    ui_print "  [!] This module is optimized for Poco F5 (marble)"
    ui_print "  [!] Your device ($DEVICE) may not get all benefits"
    ui_print ""
fi

ui_print "  Installing optimization scripts..."
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/eva_sync_engine.sh 0 0 0755
set_perm $MODPATH/gpu_optimizer.sh 0 0 0755
set_perm $MODPATH/scheduler_optimizer.sh 0 0 0755
set_perm $MODPATH/memory_optimizer.sh 0 0 0755
set_perm $MODPATH/sfopt.sh 0 0 0755
set_perm $MODPATH/govpreload.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755

# Create config directory
mkdir -p /data/adb/.config/project-evangelion/state

# Copy perflist and gov.conf
cp "$MODPATH/perflist.txt" /data/adb/.config/project-evangelion/perflist.txt 2>/dev/null
cp "$MODPATH/gov.conf" /data/adb/.config/project-evangelion/gov.conf 2>/dev/null

# Copy notification icon
cp "$MODPATH/idk.png" /data/local/tmp/idk.png 2>/dev/null

ui_print ""
ui_print "  [*] Optimizations installed:"
ui_print "      - WALT scheduler tuning (SM7475)"
ui_print "      - Adreno 725 GPU optimization"
ui_print "      - Goodix touch driver tuning"
ui_print "      - LPDDR5 memory management"
ui_print "      - UFS 3.1 I/O optimization"
ui_print "      - BBR TCP congestion control"
ui_print "      - IRQ affinity (1+3+4 topology)"
ui_print "      - Thermal management"
ui_print "      - SurfaceFlinger frame pacing"
ui_print "      - EVA Sync Engine v3.0 (real-time)"
ui_print "      - Toast notifications"
ui_print ""
ui_print "  [*] v3.0 New features:"
ui_print "      - GPU burst mode (force_bus/clk/rail)"
ui_print "      - Dynamic GPU governor switching"
ui_print "      - Smart thermal control (>45C/50C)"
ui_print "      - Game thread pinning (big/prime)"
ui_print "      - CPU scheduler latency tuning"
ui_print "      - Network low latency for gaming"
ui_print "      - RAM cache clearing on game launch"
ui_print "      - Game loading boost (30s GPU max)"
ui_print "      - THERMAL mode (auto-throttle)"
ui_print "      - Debug diagnostics (action.sh debug)"
ui_print "      - Comprehensive debug logging"
ui_print ""
ui_print "  Reboot to activate."
ui_print "======================================"
